# StaneHub – boutique d'abonnements numériques

Projet React + Vite + Tailwind + Supabase, prêt à être déployé sur Vercel.

- Boutique : accueil, catalogue, packs, fiche produit, panier, commande (mobile money + capture de paiement), suivi de commande, revendeur, blog, FAQ, contact.
- Admin (`/admin`) : tableau de bord, commandes (valider, livrer, relancer par WhatsApp, voir la preuve), produits et packs, catégories, codes promo, demandes de revendeurs, témoignages, blog, paramètres (numéros de paiement, WhatsApp, messages).
- Les prix sont recalculés côté serveur au moment de la commande (fonction SQL `create_order`).

## 1. Base Supabase (déjà installée sur le projet « Stanehub »)

Le schéma de `supabase/schema.sql` est déjà appliqué et les produits de départ sont en place. Il reste à créer ton compte admin (étapes 3 et 4 ci-dessous).

### Si tu repars d'un autre projet Supabase

1. Crée un projet sur https://supabase.com.
2. Ouvre **SQL Editor**, colle tout le contenu de `supabase/schema.sql` et clique sur **Run**.
3. Dans **Authentication > Users**, crée ton compte admin (email + mot de passe, coche « Auto Confirm »).
4. Toujours dans le SQL Editor, donne-lui les droits admin :

```sql
insert into admins (user_id) select id from auth.users where email = 'ton@email.com';
```

5. Dans **Project Settings > API**, copie l'URL du projet et la clé `anon` (ou `publishable`).

## 2. Lancer en local

```bash
npm install
cp .env.example .env     # puis colle l'URL et la clé Supabase
npm run dev
```

## 3. Déployer sur Vercel

1. Mets le dossier sur GitHub.
2. Sur https://vercel.com : **Add New > Project**, choisis le dépôt (Framework : Vite, détecté automatiquement).
3. Dans **Environment Variables**, ajoute `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY`.
4. Clique sur **Deploy**. Le fichier `vercel.json` gère les routes (`/admin`, `/produit/...`).

## 4. Personnaliser

- Connecte-toi sur `/admin/reglages` : nom de la boutique, numéro WhatsApp (format `22670000000`), numéros Orange Money, Moov Money et Wave, messages WhatsApp.
- Ajoute tes vrais produits et prix dans `/admin/produits` (les produits de départ sont des exemples).
- Les couleurs sont dans `src/index.css` (variables) et `tailwind.config.js`.

## 5. Livraison automatique avec le fournisseur (Galaxy Shop)

La fonction `supabase/functions/supplier/index.ts` est déjà déployée sur le projet. Elle commande chez le fournisseur et enregistre les codes reçus dans la commande.

1. Dans `/admin/fournisseur`, colle ta clé API du fournisseur dans le champ prévu : elle est testée puis enregistrée côté serveur (table privée `private_settings`, inaccessible depuis le navigateur). Elle n'est jamais affichée en entier.
2. Sur la même page, regarde ton solde et la liste des produits avec leur ID.
3. Dans `/admin/produits`, écris l'ID dans chaque option : `3 mois = 9500 | 55`.
4. Quand une commande est payée, clique sur **Valider le paiement** puis **Livrer automatiquement**. Les codes arrivent dans la commande et le message WhatsApp de livraison.

Garde-fous : la fonction n'accepte que les administrateurs connectés, et chaque article part avec un `client_order_id` fixe (`SH-XXXXXX-0`, `-1`, ...), donc un second clic ne facture jamais deux fois.
