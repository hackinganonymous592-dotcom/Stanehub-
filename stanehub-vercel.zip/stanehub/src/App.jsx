import { Route, Routes } from "react-router-dom";
import Layout from "./components/Layout";
import Home from "./pages/Home";
import Products from "./pages/Products";
import Product from "./pages/Product";
import Checkout from "./pages/Checkout";
import Orders from "./pages/Orders";
import Reseller from "./pages/Reseller";
import { Blog, Post } from "./pages/Blog";
import { Faq, Contact, Legal, Testimonials, NotFound } from "./pages/Info";
import AdminLayout from "./admin/AdminLayout";
import Dashboard from "./admin/Dashboard";
import AdminOrders from "./admin/AdminOrders";
import AdminProducts from "./admin/AdminProducts";
import { AdminCategories, AdminCoupons, AdminResellers, AdminTestimonials, AdminPosts } from "./admin/AdminLists";
import AdminSettings from "./admin/AdminSettings";
import AdminSupplier from "./admin/AdminSupplier";

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="produits" element={<Products />} />
        <Route path="packs" element={<Products packs />} />
        <Route path="produit/:slug" element={<Product />} />
        <Route path="commande" element={<Checkout />} />
        <Route path="commandes" element={<Orders />} />
        <Route path="revendeur" element={<Reseller />} />
        <Route path="blog" element={<Blog />} />
        <Route path="blog/:slug" element={<Post />} />
        <Route path="faq" element={<Faq />} />
        <Route path="contact" element={<Contact />} />
        <Route path="temoignages" element={<Testimonials />} />
        <Route path="page/:slug" element={<Legal />} />
        <Route path="*" element={<NotFound />} />
      </Route>
      <Route path="admin" element={<AdminLayout />}>
        <Route index element={<Dashboard />} />
        <Route path="commandes" element={<AdminOrders />} />
        <Route path="produits" element={<AdminProducts />} />
        <Route path="categories" element={<AdminCategories />} />
        <Route path="promos" element={<AdminCoupons />} />
        <Route path="revendeurs" element={<AdminResellers />} />
        <Route path="avis" element={<AdminTestimonials />} />
        <Route path="blog" element={<AdminPosts />} />
        <Route path="fournisseur" element={<AdminSupplier />} />
        <Route path="reglages" element={<AdminSettings />} />
      </Route>
    </Routes>
  );
}
