import { useEffect, useState } from "react";
import { Link, NavLink, Outlet } from "react-router-dom";
import { LogOut } from "lucide-react";
import { supabase } from "../lib/supabase";
import { Spinner } from "../components/ui";

const TABS = [
  ["/admin", "Tableau de bord", true],
  ["/admin/commandes", "Commandes"],
  ["/admin/produits", "Produits"],
  ["/admin/categories", "Catégories"],
  ["/admin/promos", "Codes promo"],
  ["/admin/fournisseur", "Fournisseur"],
  ["/admin/revendeurs", "Revendeurs"],
  ["/admin/avis", "Témoignages"],
  ["/admin/blog", "Blog"],
  ["/admin/reglages", "Paramètres"],
];

function Login() {
  const [f, setF] = useState({ email: "", password: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setErr("");
    const { error } = await supabase.auth.signInWithPassword(f);
    if (error) setErr("Email ou mot de passe incorrect.");
    setBusy(false);
  }
  return (
    <div className="grid min-h-screen place-items-center p-4">
      <form onSubmit={submit} className="card grid w-full max-w-sm gap-4 p-6">
        <h1 className="text-2xl font-extrabold">Espace admin</h1>
        <label className="grid gap-1.5 text-sm font-semibold">Email<input className="input" type="email" autoComplete="username" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} required /></label>
        <label className="grid gap-1.5 text-sm font-semibold">Mot de passe<input className="input" type="password" autoComplete="current-password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} required /></label>
        {err && <p role="alert" className="text-sm font-semibold text-red-600 dark:text-red-400">{err}</p>}
        <button className="btn" disabled={busy}>{busy ? "Connexion..." : "Se connecter"}</button>
        <Link to="/" className="text-center text-sm text-muted hover:underline">Retour à la boutique</Link>
      </form>
    </div>
  );
}

export default function AdminLayout() {
  const [session, setSession] = useState(undefined);
  const [isAdmin, setIsAdmin] = useState(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session) return setIsAdmin(null);
    supabase.rpc("is_admin").then(({ data }) => setIsAdmin(Boolean(data)));
  }, [session]);

  if (session === undefined) return <Spinner />;
  if (!session) return <Login />;
  if (isAdmin === null) return <Spinner />;
  if (!isAdmin)
    return (
      <div className="grid min-h-screen place-items-center p-4">
        <div className="card grid max-w-md gap-3 p-6">
          <h1 className="text-2xl font-extrabold">Accès refusé</h1>
          <p className="text-muted">Ce compte n'est pas administrateur. Ajoute-le dans la table <code>admins</code> (voir le README).</p>
          <button className="btn btn-line" onClick={() => supabase.auth.signOut()}>Se déconnecter</button>
        </div>
      </div>
    );

  return (
    <div className="min-h-screen">
      <header className="border-b border-line bg-card">
        <div className="wrap flex h-14 items-center justify-between">
          <Link to="/" className="font-extrabold">← Boutique</Link>
          <button className="btn btn-line btn-sm" onClick={() => supabase.auth.signOut()}><LogOut size={16} /> Déconnexion</button>
        </div>
        <nav className="wrap flex gap-2 overflow-x-auto pb-3" aria-label="Sections admin">
          {TABS.map(([to, label, end]) => (
            <NavLink key={to} to={to} end={end} className={({ isActive }) => "chip shrink-0 " + (isActive ? "!border-primary !bg-primary !text-[#1B1204]" : "")}>
              {label}
            </NavLink>
          ))}
        </nav>
      </header>
      <div className="wrap py-6">
        <Outlet />
      </div>
    </div>
  );
}
