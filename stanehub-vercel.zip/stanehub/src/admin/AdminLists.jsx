import { supabase } from "../lib/supabase";
import { useAsync } from "../lib/useAsync";
import Crud from "./Crud";
import { Spinner } from "../components/ui";
import { dstr, fmt, slugify, waLink } from "../lib/format";
import { useSettings } from "../context/SettingsContext";

export const AdminCategories = () => (
  <Crud
    table="categories"
    title="Catégories"
    orderBy="position"
    ascending
    defaults={{ name: "", emoji: "🛍", position: 0 }}
    fields={[
      { key: "name", label: "Nom", type: "text" },
      { key: "emoji", label: "Emoji", type: "text" },
      { key: "position", label: "Position (ordre d'affichage)", type: "number" },
    ]}
    primary={(r) => `${r.emoji} ${r.name}`}
    secondary={(r) => `position ${r.position}`}
  />
);

export const AdminCoupons = () => (
  <Crud
    table="coupons"
    title="Codes promo"
    orderBy="code"
    ascending
    defaults={{ code: "", kind: "pct", value: 10, active: true }}
    fields={[
      { key: "code", label: "Code", type: "text" },
      { key: "kind", label: "Type de remise", type: "select", options: [{ value: "pct", label: "Pourcentage" }, { value: "flat", label: "Montant fixe (FCFA)" }] },
      { key: "value", label: "Valeur", type: "number" },
      { key: "active", label: "Actif", type: "checkbox" },
    ]}
    toRow={(row) => ({ ...row, code: row.code.trim().toUpperCase() })}
    primary={(r) => r.code}
    secondary={(r) => `${r.kind === "pct" ? r.value + " %" : fmt(r.value)} · ${r.active ? "actif" : "désactivé"}`}
  />
);

export const AdminTestimonials = () => (
  <Crud
    table="testimonials"
    title="Témoignages"
    defaults={{ name: "", city: "", text: "", active: true }}
    fields={[
      { key: "name", label: "Nom", type: "text" },
      { key: "city", label: "Ville", type: "text" },
      { key: "text", label: "Avis", type: "textarea" },
      { key: "active", label: "Affiché sur le site", type: "checkbox" },
    ]}
    primary={(r) => r.name}
    secondary={(r) => `${r.city} · ${r.active ? "affiché" : "masqué"} · ${r.text.slice(0, 60)}`}
  />
);

export const AdminPosts = () => (
  <Crud
    table="posts"
    title="Articles du blog"
    defaults={{ title: "", excerpt: "", body: "", published: true }}
    fields={[
      { key: "title", label: "Titre", type: "text" },
      { key: "excerpt", label: "Résumé", type: "textarea" },
      { key: "body", label: "Contenu", type: "textarea", hint: "Un paragraphe par ligne." },
      { key: "published", label: "Publié", type: "checkbox" },
    ]}
    toRow={(row, isNew) => {
      if (!row.title.trim()) throw new Error("Le titre est obligatoire.");
      return isNew ? { ...row, slug: slugify(row.title) + "-" + Math.random().toString(36).slice(2, 5) } : row;
    }}
    primary={(r) => r.title}
    secondary={(r) => `${dstr(r.created_at)} · ${r.published ? "publié" : "brouillon"}`}
  />
);

export function AdminResellers() {
  const { settings } = useSettings();
  const res = useAsync(() => supabase.from("reseller_requests").select("*").order("created_at", { ascending: false }).then(({ data, error }) => { if (error) throw error; return data; }));
  const set = async (id, status) => {
    await supabase.from("reseller_requests").update({ status }).eq("id", id);
    res.reload();
  };
  const tag = { pending: ["En attente", "bg-amber-100 text-amber-800"], approved: ["Approuvé", "bg-emerald-100 text-emerald-800"], rejected: ["Refusé", "bg-red-100 text-red-800"] };
  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-extrabold">Demandes de revendeurs</h1>
      {res.loading ? <Spinner /> : (res.data || []).length === 0 ? (
        <div className="rounded-2xl border border-dashed border-line p-8 text-center text-muted">Aucune demande.</div>
      ) : res.data.map((r) => (
        <div key={r.id} className="card grid gap-2 p-4">
          <div className="flex items-center justify-between"><b>{r.name}</b><span className={"rounded-full px-2.5 py-0.5 text-xs font-bold " + tag[r.status][1]}>{tag[r.status][0]}</span></div>
          <div className="text-sm text-muted">{r.phone} · {r.city || "-"} · {dstr(r.created_at)}</div>
          <div className="flex flex-wrap gap-2">
            {r.status !== "approved" && <button className="btn btn-sm" onClick={() => set(r.id, "approved")}>Approuver</button>}
            {r.status !== "rejected" && <button className="btn btn-bad btn-sm" onClick={() => set(r.id, "rejected")}>Refuser</button>}
            <a className="btn btn-line btn-sm" target="_blank" rel="noreferrer" href={waLink(r.phone, `Bonjour ${r.name}, à propos de ta demande de revendeur`)}>WhatsApp</a>
          </div>
        </div>
      ))}
    </div>
  );
}
