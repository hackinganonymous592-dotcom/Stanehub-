import { useState } from "react";
import { supabase } from "../lib/supabase";
import { useAsync } from "../lib/useAsync";
import { ErrorBox, Spinner, StatusTag } from "../components/ui";
import { useSettings } from "../context/SettingsContext";
import { dstr, fill, fmt, orderVars, STATUS, waLink } from "../lib/format";

export default function AdminOrders() {
  const { settings } = useSettings();
  const [filter, setFilter] = useState("all");
  const res = useAsync(() => supabase.from("orders").select("*").order("created_at", { ascending: false }).then(({ data, error }) => { if (error) throw error; return data; }));

  async function setStatus(o, status) {
    const { error } = await supabase.from("orders").update({ status }).eq("id", o.id);
    if (error) return window.alert(error.message);
    res.reload();
    if (status === "delivered") window.open(waLink(o.customer_phone, fill(settings.tpl_delivered, orderVars(o))), "_blank", "noopener");
  }

  const [busyId, setBusyId] = useState(null);
  const [notice, setNotice] = useState("");

  async function autoDeliver(o) {
    setBusyId(o.id);
    setNotice("");
    try {
      const { data, error } = await supabase.functions.invoke("supplier", { body: { action: "deliver", order_id: o.id } });
      if (error) throw new Error(error.message || "Appel impossible");
      if (data?.error && !data?.status) throw new Error(data.error);
      const fresh = { ...o, delivery: data.delivery || [], status: data.status };
      if (data.error) setNotice(`${o.code} : ${data.error}`);
      res.reload();
      if (data.status === "delivered") window.open(waLink(o.customer_phone, fill(settings.tpl_delivered, orderVars(fresh))), "_blank", "noopener");
    } catch (e) {
      setNotice(`${o.code} : ${e.message}`);
    } finally {
      setBusyId(null);
    }
  }

  async function viewProof(o) {
    const { data, error } = await supabase.storage.from("proofs").createSignedUrl(o.proof_path, 300);
    if (error) return window.alert("Impossible d'ouvrir la preuve : " + error.message);
    window.open(data.signedUrl, "_blank", "noopener");
  }

  const list = (res.data || []).filter((o) => filter === "all" || o.status === filter);
  return (
    <div className="grid gap-4">
      <h1 className="text-2xl font-extrabold">Commandes</h1>
      <div className="flex gap-2 overflow-x-auto pb-1">
        {[["all", "Toutes"], ...Object.entries(STATUS).map(([k, v]) => [k, v.label])].map(([k, l]) => (
          <button key={k} className="chip shrink-0" aria-pressed={filter === k} onClick={() => setFilter(k)}>{l}</button>
        ))}
      </div>
      {notice && <p role="alert" className="rounded-xl bg-amber-100 p-3 text-sm font-semibold text-amber-900">{notice}</p>}
      {res.loading ? <Spinner /> : res.error ? <ErrorBox error={res.error} /> : list.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-line p-8 text-center text-muted">Aucune commande dans cette catégorie.</div>
      ) : list.map((o) => (
        <div key={o.id} className="card grid gap-2 p-4">
          <div className="flex items-center justify-between"><b>{o.code}</b><StatusTag s={o.status} /></div>
          <div><b>{o.customer_name}</b> <span className="text-sm text-muted">{o.customer_phone} · {dstr(o.created_at)}</span></div>
          {o.items.map((i, k) => (
            <div key={k} className="flex justify-between text-sm"><span>{i.name}, {i.option} × {i.qty}</span><span>{fmt(i.total)}</span></div>
          ))}
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted">{o.method}{o.coupon ? ` · code ${o.coupon}` : ""}</span>
            <b>{fmt(o.total)}</b>
          </div>
          {o.supplier_error && <p className="text-sm font-semibold text-amber-700 dark:text-amber-300">⚠ {o.supplier_error}</p>}
          {(o.delivery || []).length > 0 && (
            <div className="rounded-xl bg-soft p-3 text-sm">
              <b>Codes livrés</b>
              {o.delivery.map((d, k) => <div key={k}><span className="text-muted">{d.name} {d.option} :</span> {(d.codes || []).join(" · ")}</div>)}
            </div>
          )}
          <div className="flex flex-wrap gap-2">
            {o.proof_path && <button className="btn btn-line btn-sm" onClick={() => viewProof(o)}>Voir la preuve</button>}
            {o.status === "pending" && (
              <>
                <button className="btn btn-sm" onClick={() => setStatus(o, "paid")}>Valider le paiement</button>
                <a className="btn btn-line btn-sm" target="_blank" rel="noreferrer" href={waLink(o.customer_phone, fill(settings.tpl_relance, orderVars(o)))}>Relancer</a>
                <button className="btn btn-bad btn-sm" onClick={() => setStatus(o, "cancelled")}>Annuler</button>
              </>
            )}
            {o.status === "paid" && (
              <>
                {o.items.some((i) => i.supplier_id) && (
                  <button className="btn btn-sm" disabled={busyId === o.id} onClick={() => autoDeliver(o)}>{busyId === o.id ? "Livraison..." : "Livrer automatiquement"}</button>
                )}
                <button className="btn btn-teal btn-sm" onClick={() => setStatus(o, "delivered")}>Marquer livrée à la main</button>
                <button className="btn btn-bad btn-sm" onClick={() => setStatus(o, "cancelled")}>Annuler</button>
              </>
            )}
            {(o.status === "delivered" || o.status === "cancelled") && (
              <a className="btn btn-line btn-sm" target="_blank" rel="noreferrer" href={waLink(o.customer_phone, `Bonjour ${o.customer_name}, à propos de ta commande ${o.code}`)}>Écrire au client</a>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
