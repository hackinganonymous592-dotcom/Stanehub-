import { getCategories } from "../lib/api";
import { useAsync } from "../lib/useAsync";
import { Spinner } from "../components/ui";
import Crud from "./Crud";
import { fmt, minPrice, slugify } from "../lib/format";

const parseVariants = (txt) =>
  String(txt || "")
    .split("\n")
    .map((l) => {
      const [main, sup] = l.split("|");
      const i = main.lastIndexOf("=");
      if (i < 0) return null;
      const v = { label: main.slice(0, i).trim(), price: Number(main.slice(i + 1).replace(/\s/g, "")) };
      if (sup && sup.trim()) v.supplier_id = sup.trim();
      return v;
    })
    .filter((v) => v && v.label && v.price > 0);

export default function AdminProducts() {
  const cats = useAsync(getCategories);
  if (cats.loading) return <Spinner />;
  const options = [{ value: "", label: "Aucune" }, ...(cats.data || []).map((c) => ({ value: c.id, label: c.emoji + " " + c.name }))];
  return (
    <Crud
      table="products"
      title="Produits et packs"
      ascending
      defaults={{ name: "", category_id: "", description: "", color: "#2563EB", initials: "", variants: "1 mois = 2000", stock: -1, featured: false, active: true, is_pack: false, includes: "" }}
      fields={[
        { key: "name", label: "Nom", type: "text" },
        { key: "category_id", label: "Catégorie", type: "select", options },
        { key: "description", label: "Description", type: "textarea" },
        { key: "variants", label: "Options et prix", type: "textarea", hint: "Une option par ligne : option = prix | ID fournisseur (facultatif). Exemple : 3 mois = 9500 | 55. Avec un ID fournisseur, la livraison peut être automatique." },
        { key: "stock", label: "Stock", type: "number", hint: "-1 = illimité, 0 = rupture" },
        { key: "initials", label: "Initiales du logo", type: "text" },
        { key: "color", label: "Couleur du logo", type: "color" },
        { key: "is_pack", label: "C'est un pack", type: "checkbox" },
        { key: "includes", label: "Contenu du pack (une ligne par service)", type: "textarea" },
        { key: "featured", label: "Mettre en avant sur l'accueil", type: "checkbox" },
        { key: "active", label: "Visible dans la boutique", type: "checkbox" },
      ]}
      fromRow={(r) => ({ ...r, category_id: r.category_id || "", variants: (r.variants || []).map((v) => `${v.label} = ${v.price}${v.supplier_id ? " | " + v.supplier_id : ""}`).join("\n") })}
      toRow={(row, isNew) => {
        const variants = parseVariants(row.variants);
        if (!row.name.trim()) throw new Error("Le nom est obligatoire.");
        if (!variants.length) throw new Error("Ajoute au moins une option, par exemple : 1 mois = 2500");
        const out = { ...row, name: row.name.trim(), variants, initials: row.initials || row.name.slice(0, 2) };
        if (isNew) out.slug = slugify(row.name) + "-" + Math.random().toString(36).slice(2, 5);
        return out;
      }}
      primary={(r) => `${r.name}${r.is_pack ? " (pack)" : ""}`}
      secondary={(r) => `dès ${fmt(minPrice(r))} · stock : ${r.stock < 0 ? "illimité" : r.stock}${r.active ? "" : " · masqué"}${r.featured ? " · mis en avant" : ""}`}
    />
  );
}
