import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import { useSettings } from "../context/SettingsContext";

export default function AdminSettings() {
  const { settings, reload } = useSettings();
  const [f, setF] = useState(null);
  const [newMethod, setNewMethod] = useState({ name: "", number: "" });
  const [msg, setMsg] = useState("");

  useEffect(() => { setF({ ...settings, pay_methods: { ...settings.pay_methods } }); }, [settings]);
  if (!f) return null;

  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function save() {
    setMsg("");
    const pay = { ...f.pay_methods };
    if (newMethod.name.trim() && newMethod.number.trim()) pay[newMethod.name.trim()] = newMethod.number.trim();
    const rows = [
      { key: "shop_name", value: f.shop_name },
      { key: "whatsapp", value: String(f.whatsapp).replace(/\D/g, "") },
      { key: "pay_methods", value: pay },
      { key: "tpl_order", value: f.tpl_order },
      { key: "tpl_delivered", value: f.tpl_delivered },
      { key: "tpl_relance", value: f.tpl_relance },
    ];
    const { error } = await supabase.from("settings").upsert(rows);
    if (error) return setMsg("Erreur : " + error.message);
    setNewMethod({ name: "", number: "" });
    reload();
    setMsg("Paramètres enregistrés.");
  }

  return (
    <div className="grid max-w-2xl gap-5">
      <h1 className="text-2xl font-extrabold">Paramètres</h1>
      <section className="card grid gap-4 p-5">
        <h2 className="text-lg font-extrabold">Boutique</h2>
        <label className="grid gap-1.5 text-sm font-semibold">Nom de la boutique<input className="input" value={f.shop_name} onChange={set("shop_name")} /></label>
        <label className="grid gap-1.5 text-sm font-semibold">Numéro WhatsApp (format international, sans +)<input className="input" inputMode="numeric" value={f.whatsapp} onChange={set("whatsapp")} /></label>
      </section>
      <section className="card grid gap-4 p-5">
        <h2 className="text-lg font-extrabold">Moyens de paiement</h2>
        {Object.entries(f.pay_methods).map(([m, n]) => (
          <div key={m} className="flex items-end gap-2">
            <label className="grid flex-1 gap-1.5 text-sm font-semibold">{m}<input className="input" value={n} onChange={(e) => setF({ ...f, pay_methods: { ...f.pay_methods, [m]: e.target.value } })} /></label>
            <button className="btn btn-bad btn-sm" onClick={() => { const p = { ...f.pay_methods }; delete p[m]; setF({ ...f, pay_methods: p }); }}>Retirer</button>
          </div>
        ))}
        <div className="grid gap-2 sm:grid-cols-2">
          <input className="input" placeholder="Nouveau moyen (ex : Coris Money)" value={newMethod.name} onChange={(e) => setNewMethod({ ...newMethod, name: e.target.value })} aria-label="Nom du nouveau moyen de paiement" />
          <input className="input" placeholder="Numéro" value={newMethod.number} onChange={(e) => setNewMethod({ ...newMethod, number: e.target.value })} aria-label="Numéro du nouveau moyen de paiement" />
        </div>
      </section>
      <section className="card grid gap-4 p-5">
        <h2 className="text-lg font-extrabold">Messages WhatsApp</h2>
        <p className="text-sm text-muted">Variables disponibles : {"{nom} {id} {produits} {total}"}</p>
        <label className="grid gap-1.5 text-sm font-semibold">Commande reçue<textarea className="input min-h-[80px]" value={f.tpl_order} onChange={set("tpl_order")} /></label>
        <label className="grid gap-1.5 text-sm font-semibold">Commande livrée<textarea className="input min-h-[80px]" value={f.tpl_delivered} onChange={set("tpl_delivered")} /></label>
        <label className="grid gap-1.5 text-sm font-semibold">Relance de paiement<textarea className="input min-h-[80px]" value={f.tpl_relance} onChange={set("tpl_relance")} /></label>
      </section>
      {msg && <p role="status" className="font-semibold">{msg}</p>}
      <button className="btn w-fit" onClick={save}>Enregistrer</button>
    </div>
  );
}
