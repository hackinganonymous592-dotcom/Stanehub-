import { useState } from "react";
import { supabase } from "../lib/supabase";
import { useAsync } from "../lib/useAsync";
import { ErrorBox, Spinner } from "../components/ui";
import { fmt } from "../lib/format";

async function call(action, extra = {}) {
  const { data, error } = await supabase.functions.invoke("supplier", { body: { action, ...extra } });
  if (error) throw new Error(error.message || "Appel impossible");
  if (data?.error) throw new Error(data.error);
  return data;
}

function KeyCard({ status, onChange }) {
  const [value, setValue] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState({ type: "", text: "" });

  async function save(e) {
    e.preventDefault();
    setBusy(true);
    setMsg({ type: "", text: "" });
    try {
      const r = await call("set_key", { key: value });
      setValue("");
      setMsg({ type: "ok", text: `Clé enregistrée et vérifiée (solde : ${r.balance_usd ?? "?"} $).` });
      onChange();
    } catch (err) {
      setMsg({ type: "err", text: err.message });
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    if (!window.confirm("Supprimer la clé fournisseur ? La livraison automatique sera désactivée.")) return;
    setBusy(true);
    try {
      await call("delete_key");
      setMsg({ type: "ok", text: "Clé supprimée." });
      onChange();
    } catch (err) {
      setMsg({ type: "err", text: err.message });
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={save} className="card grid gap-3 p-5">
      <h2 className="text-lg font-extrabold">Clé API du fournisseur</h2>
      {status.configured ? (
        <p className="text-sm">Clé enregistrée : <b>••••••••{status.last4}</b></p>
      ) : (
        <p className="text-sm text-muted">Aucune clé enregistrée. Colle ta clé (elle commence par <code>Galaxy_</code>) pour activer la livraison automatique.</p>
      )}
      <label className="grid gap-1.5 text-sm font-semibold">
        {status.configured ? "Remplacer par une nouvelle clé" : "Clé API"}
        <input className="input" type="password" autoComplete="off" spellCheck="false" placeholder="Galaxy_..." value={value} onChange={(e) => setValue(e.target.value)} />
      </label>
      {msg.text && (
        <p role="status" className={"text-sm font-semibold " + (msg.type === "err" ? "text-red-600 dark:text-red-400" : "text-emerald-700 dark:text-emerald-400")}>{msg.text}</p>
      )}
      <div className="flex flex-wrap gap-2">
        <button className="btn" disabled={busy || value.trim().length < 12}>{busy ? "Vérification..." : "Enregistrer la clé"}</button>
        {status.configured && <button type="button" className="btn btn-bad" disabled={busy} onClick={remove}>Supprimer la clé</button>}
      </div>
      <p className="text-xs text-muted">La clé est testée avant d'être enregistrée. Elle est stockée côté serveur, jamais affichée en entier et jamais envoyée au navigateur des visiteurs.</p>
    </form>
  );
}

function Catalogue() {
  const [rate, setRate] = useState(600);
  const bal = useAsync(() => call("balance"));
  const list = useAsync(() => call("products"));
  return (
    <>
      <div className="card grid gap-1 p-5">
        <span className="text-sm text-muted">Solde chez le fournisseur</span>
        {bal.loading ? <b>Chargement...</b> : bal.error ? <span className="text-sm font-semibold text-red-600 dark:text-red-400">{bal.error.message}</span> : (
          <b className="text-3xl font-extrabold">{bal.data.balance_usd} $</b>
        )}
        <span className="text-sm text-muted">Recharge ce solde depuis le bot Telegram du fournisseur (Deposit). Une commande échoue si le solde est trop bas.</span>
      </div>

      <label className="grid max-w-xs gap-1.5 text-sm font-semibold">Taux pour estimer le coût en FCFA (1 $ =)
        <input className="input" type="number" value={rate} onChange={(e) => setRate(Number(e.target.value) || 0)} />
      </label>

      {list.loading ? <Spinner /> : list.error ? <ErrorBox error={list.error} /> : (
        <div className="grid gap-2">
          {(list.data.products || []).map((p) => (
            <div key={p.id} className="card flex flex-wrap items-center justify-between gap-2 p-3">
              <div className="min-w-0">
                <b className="block truncate">{p.name}</b>
                <span className="text-sm text-muted">ID <code>{p.id}</code> · {p.unlimited_stock ? "stock illimité" : "stock : " + p.stock}</span>
              </div>
              <div className="text-right">
                <b>{p.price_usd} $</b>
                <div className="text-sm text-muted">≈ {fmt(p.price_usd * rate)} de coût</div>
              </div>
            </div>
          ))}
          {(list.data.products || []).length === 0 && <div className="rounded-2xl border border-dashed border-line p-8 text-center text-muted">Aucun produit renvoyé par le fournisseur.</div>}
        </div>
      )}
    </>
  );
}

export default function AdminSupplier() {
  const status = useAsync(() => call("key_status"));
  return (
    <div className="grid gap-5">
      <div>
        <h1 className="text-2xl font-extrabold">Fournisseur : Galaxy Shop</h1>
        <p className="text-sm text-muted">Pour livrer automatiquement, copie l'ID d'un produit ci-dessous dans l'option correspondante, sous Produits (format : option = prix | ID).</p>
      </div>
      {status.loading ? <Spinner /> : status.error ? <ErrorBox error={status.error} /> : (
        <>
          <KeyCard status={status.data} onChange={status.reload} />
          {status.data.configured && <Catalogue key={status.data.last4} />}
        </>
      )}
    </div>
  );
}
