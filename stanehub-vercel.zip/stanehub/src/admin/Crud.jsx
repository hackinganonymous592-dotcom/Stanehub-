import { useState } from "react";
import { supabase } from "../lib/supabase";
import { useAsync } from "../lib/useAsync";
import { ErrorBox, Spinner } from "../components/ui";

/**
 * Écran CRUD générique.
 * fields : [{ key, label, type: text|textarea|number|checkbox|color|select, options?, hint? }]
 */
export default function Crud({ table, title, fields, defaults, orderBy = "created_at", ascending = false, primary, secondary, fromRow, toRow }) {
  const list = useAsync(() => supabase.from(table).select("*").order(orderBy, { ascending }).then(({ data, error }) => { if (error) throw error; return data; }), [table]);
  const [form, setForm] = useState(null); // null = fermé
  const [editId, setEditId] = useState(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const openNew = () => { setEditId(null); setErr(""); setForm({ ...defaults }); };
  const openEdit = (row) => { setEditId(row.id); setErr(""); setForm(fromRow ? fromRow(row) : { ...row }); };

  async function save() {
    setErr("");
    setBusy(true);
    try {
      let row = {};
      for (const f of fields) {
        let v = form[f.key];
        if (f.type === "number") v = Number(v);
        if (f.type === "select" && v === "") v = null;
        row[f.key] = v;
      }
      if (toRow) row = toRow(row, !editId);
      const q = editId ? supabase.from(table).update(row).eq("id", editId) : supabase.from(table).insert(row);
      const { error } = await q;
      if (error) throw error;
      setForm(null);
      list.reload();
    } catch (e) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function remove(row) {
    if (!window.confirm("Supprimer définitivement cet élément ?")) return;
    const { error } = await supabase.from(table).delete().eq("id", row.id);
    if (error) window.alert(error.message);
    list.reload();
  }

  return (
    <div className="grid gap-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-extrabold">{title} {list.data ? `(${list.data.length})` : ""}</h1>
        <button className="btn btn-sm" onClick={openNew}>Ajouter</button>
      </div>
      {list.loading ? <Spinner /> : list.error ? <ErrorBox error={list.error} /> : list.data.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-line p-8 text-center text-muted">Rien pour l'instant.</div>
      ) : (
        <div className="grid gap-3">
          {list.data.map((r) => (
            <div key={r.id} className="card flex flex-wrap items-center justify-between gap-3 p-4">
              <div className="min-w-0">
                <b className="block truncate">{primary(r)}</b>
                <span className="text-sm text-muted">{secondary?.(r)}</span>
              </div>
              <div className="flex gap-2">
                <button className="btn btn-line btn-sm" onClick={() => openEdit(r)}>Modifier</button>
                <button className="btn btn-bad btn-sm" onClick={() => remove(r)}>Supprimer</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {form && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 sm:items-center" role="dialog" aria-modal="true">
          <div className="max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-t-3xl border border-line bg-bg p-5 sm:rounded-3xl" style={{ paddingBottom: "calc(1.25rem + env(safe-area-inset-bottom, 0px))" }}>
            <h2 className="mb-4 text-xl font-extrabold">{editId ? "Modifier" : "Ajouter"}</h2>
            <div className="grid gap-4">
              {fields.map((f) => (
                <label key={f.key} className={f.type === "checkbox" ? "flex min-h-[44px] items-center gap-3 text-sm font-semibold" : "grid gap-1.5 text-sm font-semibold"}>
                  {f.type === "checkbox" ? (
                    <>
                      <input type="checkbox" className="h-5 w-5 accent-[#FF8000]" checked={!!form[f.key]} onChange={(e) => setForm({ ...form, [f.key]: e.target.checked })} /> {f.label}
                    </>
                  ) : (
                    <>
                      {f.label}
                      {f.type === "textarea" ? (
                        <textarea className="input min-h-[100px]" value={form[f.key] ?? ""} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })} />
                      ) : f.type === "select" ? (
                        <select className="input" value={form[f.key] ?? ""} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}>
                          {f.options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                        </select>
                      ) : (
                        <input className={"input " + (f.type === "color" ? "!p-1" : "")} type={f.type} value={form[f.key] ?? ""} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })} />
                      )}
                      {f.hint && <span className="text-xs font-normal text-muted">{f.hint}</span>}
                    </>
                  )}
                </label>
              ))}
            </div>
            {err && <p role="alert" className="mt-3 text-sm font-semibold text-red-600 dark:text-red-400">{err}</p>}
            <div className="mt-5 flex justify-between gap-3">
              <button className="btn btn-line" onClick={() => setForm(null)}>Annuler</button>
              <button className="btn" disabled={busy} onClick={save}>{busy ? "Enregistrement..." : "Enregistrer"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
