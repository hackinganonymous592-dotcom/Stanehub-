import { supabase } from "../lib/supabase";
import { useAsync } from "../lib/useAsync";
import { ErrorBox, Spinner } from "../components/ui";
import { fmt } from "../lib/format";

const DAY = 864e5;

export default function Dashboard() {
  const res = useAsync(async () => {
    const [o, p, r] = await Promise.all([
      supabase.from("orders").select("*"),
      supabase.from("products").select("name, stock"),
      supabase.from("reseller_requests").select("id").eq("status", "pending"),
    ]);
    if (o.error) throw o.error;
    return { orders: o.data, products: p.data || [], pendingResellers: (r.data || []).length };
  });
  if (res.loading) return <Spinner />;
  if (res.error) return <ErrorBox error={res.error} />;
  const { orders, products, pendingResellers } = res.data;

  const ok = orders.filter((o) => o.status === "paid" || o.status === "delivered");
  const revenue = ok.reduce((a, o) => a + o.total, 0);
  const pending = orders.filter((o) => o.status === "pending").length;
  const toDeliver = orders.filter((o) => o.status === "paid").length;
  const clients = new Set(orders.map((o) => o.customer_phone.replace(/\D/g, ""))).size;

  const days = [...Array(7)].map((_, i) => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    const s = d.getTime() - (6 - i) * DAY;
    return { l: new Date(s).toLocaleDateString("fr-FR", { weekday: "short" }), v: ok.filter((o) => { const t = new Date(o.created_at).getTime(); return t >= s && t < s + DAY; }).reduce((a, o) => a + o.total, 0) };
  });
  const max = Math.max(1, ...days.map((d) => d.v));

  const count = {};
  orders.filter((o) => o.status !== "cancelled").forEach((o) => o.items.forEach((i) => (count[i.name] = (count[i.name] || 0) + i.qty)));
  const top = Object.entries(count).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const low = products.filter((p) => p.stock >= 0 && p.stock <= 5);

  const kpis = [["Chiffre d'affaires", fmt(revenue)], ["À valider", pending], ["À livrer", toDeliver], ["Clients", clients], ["Demandes revendeur", pendingResellers]];
  return (
    <div className="grid gap-5">
      <h1 className="text-2xl font-extrabold">Tableau de bord</h1>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        {kpis.map(([l, v]) => (
          <div key={l} className="card p-4"><span className="text-sm text-muted">{l}</span><b className="block text-2xl font-extrabold">{v}</b></div>
        ))}
      </div>
      <div className="card p-5">
        <h2 className="mb-3 text-lg font-extrabold">Ventes des 7 derniers jours</h2>
        <div className="flex h-40 items-end gap-2">
          {days.map((d) => (
            <div key={d.l} className="grid h-full flex-1 grid-rows-[1fr_auto] gap-1 text-center text-xs text-muted" title={fmt(d.v)}>
              <div className="flex items-end"><i className="block w-full rounded-t-md bg-gradient-to-t from-primary to-amber-300" style={{ height: Math.max(3, Math.round((d.v / max) * 100)) + "%" }} /></div>
              <span>{d.l}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <div className="card grid content-start gap-2 p-5">
          <h2 className="text-lg font-extrabold">Produits les plus vendus</h2>
          {top.length ? top.map(([n, q]) => <div key={n} className="flex justify-between"><span>{n}</span><b>{q}</b></div>) : <p className="text-sm text-muted">Pas encore de ventes.</p>}
        </div>
        <div className="card grid content-start gap-2 p-5">
          <h2 className="text-lg font-extrabold">Stock faible</h2>
          {low.length ? low.map((p) => <div key={p.name} className="flex justify-between"><span>{p.name}</span><b>{p.stock === 0 ? "Rupture" : p.stock + " restant" + (p.stock > 1 ? "s" : "")}</b></div>) : <p className="text-sm text-muted">Aucun produit en stock faible.</p>}
        </div>
      </div>
    </div>
  );
}
