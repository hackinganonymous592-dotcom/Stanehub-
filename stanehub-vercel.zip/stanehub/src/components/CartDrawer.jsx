import { Link } from "react-router-dom";
import { Minus, Plus, Trash2, X } from "lucide-react";
import { useCart } from "../context/CartContext";
import { Logo } from "./ui";
import { fmt } from "../lib/format";

export default function CartDrawer() {
  const cart = useCart();
  if (!cart.open) return null;
  const close = () => cart.setOpen(false);
  return (
    <>
      <div className="fixed inset-0 z-40 bg-black/60" onClick={close} />
      <aside className="fixed inset-y-0 right-0 z-50 flex w-full max-w-md flex-col border-l border-line bg-bg" aria-label="Panier">
        <div className="flex items-center justify-between border-b border-line bg-card px-4 py-3">
          <h2 className="text-xl font-extrabold">Panier</h2>
          <button className="grid h-11 w-11 place-items-center rounded-xl hover:bg-soft" onClick={close} aria-label="Fermer le panier">
            <X size={20} />
          </button>
        </div>
        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          {cart.items.length === 0 && (
            <div className="grid justify-items-center gap-3 rounded-2xl border border-dashed border-line p-8 text-center text-muted">
              <p>Ton panier est vide.</p>
              <Link to="/produits" className="btn" onClick={close}>
                Voir les produits
              </Link>
            </div>
          )}
          {cart.items.map((it) => (
            <div key={it.productId + it.variant} className="card grid grid-cols-[auto_1fr_auto] items-center gap-3 p-3">
              <Logo p={it} size={44} />
              <div className="min-w-0">
                <b className="block truncate">{it.name}</b>
                <div className="text-sm text-muted">
                  {it.option} · {fmt(it.price)}
                </div>
                <div className="mt-1 flex items-center gap-2">
                  <button className="grid h-9 w-9 place-items-center rounded-lg border border-line" onClick={() => cart.setQty(it, it.qty - 1)} aria-label="Retirer une unité">
                    <Minus size={16} />
                  </button>
                  <b>{it.qty}</b>
                  <button className="grid h-9 w-9 place-items-center rounded-lg border border-line" onClick={() => cart.setQty(it, it.qty + 1)} aria-label="Ajouter une unité">
                    <Plus size={16} />
                  </button>
                </div>
              </div>
              <button className="grid h-11 w-11 place-items-center rounded-xl hover:bg-soft" onClick={() => cart.remove(it)} aria-label={`Supprimer ${it.name}`}>
                <Trash2 size={18} />
              </button>
            </div>
          ))}
        </div>
        {cart.items.length > 0 && (
          <div className="space-y-3 border-t border-line bg-card p-4" style={{ paddingBottom: "calc(1rem + env(safe-area-inset-bottom, 0px))" }}>
            <div className="flex justify-between text-xl font-extrabold">
              <span>Total</span>
              <span>{fmt(cart.subtotal)}</span>
            </div>
            <Link to="/commande" className="btn w-full" onClick={close}>
              Passer au paiement
            </Link>
          </div>
        )}
      </aside>
    </>
  );
}
