import { useEffect, useState } from "react";
import { Link, NavLink, Outlet, useLocation } from "react-router-dom";
import { Home, Menu, Moon, Package, Receipt, ShoppingBag, ShoppingCart, Sun, X, MessageCircle } from "lucide-react";
import { useCart } from "../context/CartContext";
import { useSettings } from "../context/SettingsContext";
import CartDrawer from "./CartDrawer";
import { waLink } from "../lib/format";

const LINKS = [
  ["/", "Accueil"],
  ["/produits", "Produits"],
  ["/packs", "Packs"],
  ["/revendeur", "Revendeur"],
  ["/blog", "Blog"],
  ["/contact", "Contact"],
];

function ThemeButton() {
  const [dark, setDark] = useState(document.documentElement.classList.contains("dark"));
  return (
    <button
      className="grid h-11 w-11 place-items-center rounded-xl hover:bg-soft"
      aria-label="Changer le thème clair ou sombre"
      onClick={() => {
        const next = !dark;
        setDark(next);
        document.documentElement.classList.toggle("dark", next);
        try {
          localStorage.setItem("theme", next ? "dark" : "light");
        } catch {}
      }}
    >
      {dark ? <Sun size={20} /> : <Moon size={20} />}
    </button>
  );
}

export default function Layout() {
  const cart = useCart();
  const { settings } = useSettings();
  const [menu, setMenu] = useState(false);
  const { pathname } = useLocation();

  useEffect(() => {
    setMenu(false);
    window.scrollTo(0, 0);
  }, [pathname]);

  const navCls = ({ isActive }) =>
    "rounded-lg px-3 py-2 text-[15px] font-semibold " + (isActive ? "bg-soft text-fg" : "text-muted hover:text-fg");

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-line bg-card/90 backdrop-blur">
        <div className="wrap flex h-16 items-center gap-1">
          <Link to="/" className="mr-auto flex items-center gap-2 text-xl font-extrabold tracking-tight">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-primary to-amber-300 text-[#1B1204]">
              <ShoppingBag size={19} />
            </span>
            {settings.shop_name}
          </Link>
          <nav className="hidden items-center gap-0.5 min-[900px]:flex" aria-label="Navigation principale">
            {LINKS.map(([to, label]) => (
              <NavLink key={to} to={to} end={to === "/"} className={navCls}>
                {label}
              </NavLink>
            ))}
          </nav>
          <ThemeButton />
          <button className="relative grid h-11 w-11 place-items-center rounded-xl hover:bg-soft" onClick={() => cart.setOpen(true)} aria-label="Ouvrir le panier">
            <ShoppingCart size={20} />
            {cart.count > 0 && (
              <span className="absolute right-0 top-1 grid h-5 min-w-[20px] place-items-center rounded-full bg-primary px-1 text-[11px] font-extrabold text-[#1B1204]">{cart.count}</span>
            )}
          </button>
          <button className="grid h-11 w-11 place-items-center rounded-xl hover:bg-soft min-[900px]:hidden" onClick={() => setMenu(true)} aria-label="Ouvrir le menu">
            <Menu size={22} />
          </button>
        </div>
      </header>

      <main>
        <Outlet />
      </main>

      <footer className="mt-14 bg-navy py-10 text-slate-300">
        <div className="wrap grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <h4 className="mb-2 font-bold text-white">{settings.shop_name}</h4>
            <p className="text-sm">Abonnements numériques à prix réduit, livrés sur WhatsApp.</p>
            <a href={waLink(settings.whatsapp, "Bonjour")} target="_blank" rel="noreferrer" className="btn btn-sm mt-4">
              <MessageCircle size={16} /> WhatsApp
            </a>
          </div>
          <FooterCol title="Boutique" links={[["/produits", "Produits"], ["/packs", "Packs"], ["/revendeur", "Devenir revendeur"], ["/blog", "Blog"]]} />
          <FooterCol title="Aide" links={[["/commandes", "Suivre ma commande"], ["/faq", "FAQ"], ["/contact", "Contact"], ["/temoignages", "Témoignages"]]} />
          <FooterCol title="Légal" links={[["/page/conditions", "Conditions"], ["/page/confidentialite", "Confidentialité"], ["/page/remboursement", "Remboursement"], ["/admin", "Espace admin"]]} />
        </div>
        <p className="wrap mt-8 text-xs text-slate-400">© {new Date().getFullYear()} {settings.shop_name}. Les noms de services appartiennent à leurs propriétaires.</p>
      </footer>

      {/* barre mobile */}
      <nav className="fixed inset-x-0 bottom-0 z-30 flex border-t border-line bg-card min-[900px]:hidden" style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)" }} aria-label="Navigation mobile">
        {[
          ["/", Home, "Accueil"],
          ["/produits", ShoppingBag, "Produits"],
          ["/packs", Package, "Packs"],
          ["/commandes", Receipt, "Commandes"],
        ].map(([to, Icon, label]) => (
          <NavLink key={to} to={to} end={to === "/"} className={({ isActive }) => "grid min-h-[56px] flex-1 place-items-center content-center justify-items-center text-[11px] font-semibold " + (isActive ? "text-primary" : "text-muted")}>
            <Icon size={21} />
            {label}
          </NavLink>
        ))}
      </nav>

      {menu && (
        <>
          <div className="fixed inset-0 z-40 bg-black/60" onClick={() => setMenu(false)} />
          <aside className="fixed inset-y-0 left-0 z-50 w-[min(340px,100%)] border-r border-line bg-bg" aria-label="Menu">
            <div className="flex items-center justify-between border-b border-line bg-card px-4 py-3">
              <h2 className="text-xl font-extrabold">Menu</h2>
              <button className="grid h-11 w-11 place-items-center rounded-xl hover:bg-soft" onClick={() => setMenu(false)} aria-label="Fermer le menu">
                <X size={20} />
              </button>
            </div>
            <div className="grid gap-2 p-4">
              {[...LINKS, ["/commandes", "Mes commandes"], ["/faq", "FAQ"], ["/admin", "Admin"]].map(([to, label]) => (
                <Link key={to} to={to} className="card px-4 py-3 font-semibold">
                  {label}
                </Link>
              ))}
            </div>
          </aside>
        </>
      )}
      <CartDrawer />
    </div>
  );
}

function FooterCol({ title, links }) {
  return (
    <div>
      <h4 className="mb-2 font-bold text-white">{title}</h4>
      <ul className="space-y-1.5 text-sm">
        {links.map(([to, label]) => (
          <li key={to}>
            <Link to={to} className="hover:text-white">
              {label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
