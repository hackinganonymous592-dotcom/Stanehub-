import { Link } from "react-router-dom";
import { Logo } from "./ui";
import { fmt, minPrice } from "../lib/format";
import { useCart } from "../context/CartContext";

export default function ProductCard({ p }) {
  const cart = useCart();
  const out = p.stock === 0;
  return (
    <article className="card group relative grid content-start gap-3 p-4 transition hover:-translate-y-0.5 hover:border-teal hover:shadow-lift">
      <Link to={`/produit/${p.slug}`} className="flex items-center gap-3">
        <Logo p={p} />
        <div className="min-w-0">
          <h3 className="truncate text-base font-bold">{p.name}</h3>
          <div className="text-sm text-muted">{p.categories?.name || (p.is_pack ? "Packs" : "")}</div>
        </div>
      </Link>
      <div className="text-xl font-extrabold">
        <span className="mr-1 text-sm font-medium text-muted">À partir de</span>
        {fmt(minPrice(p))}
      </div>
      <div>
        {out ? (
          <span className="tag bg-red-100 text-red-800 dark:bg-red-500/20 dark:text-red-300">Rupture</span>
        ) : p.stock > 0 && p.stock <= 5 ? (
          <span className="tag bg-amber-100 text-amber-800 dark:bg-amber-500/20 dark:text-amber-300">Plus que {p.stock}</span>
        ) : (
          <span className="tag bg-teal/10 text-teal">Livraison WhatsApp</span>
        )}
      </div>
      <div className="flex gap-2">
        <Link to={`/produit/${p.slug}`} className="btn btn-line btn-sm flex-1">
          Détails
        </Link>
        <button
          className="btn btn-sm flex-1"
          disabled={out}
          onClick={() => {
            cart.add(p, 0);
            cart.setOpen(true);
          }}
        >
          Ajouter
        </button>
      </div>
    </article>
  );
}
