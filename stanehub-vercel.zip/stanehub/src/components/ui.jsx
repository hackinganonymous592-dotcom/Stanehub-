import { Link } from "react-router-dom";
import { STATUS } from "../lib/format";

export const Logo = ({ p, size = 54, className = "" }) => (
  <div
    aria-hidden="true"
    className={"grid shrink-0 place-items-center rounded-2xl font-extrabold text-white " + className}
    style={{ background: p.color, width: size, height: size, fontSize: size * 0.36 }}
  >
    {p.initials || p.name?.slice(0, 2)}
  </div>
);

export const StatusTag = ({ s }) => (
  <span className={"inline-block rounded-full px-2.5 py-0.5 text-xs font-bold " + (STATUS[s]?.cls || "")}>{STATUS[s]?.label || s}</span>
);

export const Spinner = () => (
  <div className="grid place-items-center py-16" role="status" aria-label="Chargement">
    <div className="h-8 w-8 animate-spin rounded-full border-4 border-line border-t-primary" />
  </div>
);

export const ErrorBox = ({ error }) => (
  <div className="card p-6 text-center text-red-600 dark:text-red-400" role="alert">
    Une erreur est survenue : {error?.message || "réessaie dans un instant."}
  </div>
);

export const Empty = ({ children, cta }) => (
  <div className="grid justify-items-center gap-3 rounded-2xl border border-dashed border-line p-8 text-center text-muted">
    <p>{children}</p>
    {cta && (
      <Link className="btn" to={cta.to}>
        {cta.label}
      </Link>
    )}
  </div>
);

export const SectionHead = ({ title, to, label = "Tout voir" }) => (
  <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
    <h2 className="text-2xl font-extrabold sm:text-3xl">{title}</h2>
    {to && (
      <Link className="btn btn-line btn-sm" to={to}>
        {label}
      </Link>
    )}
  </div>
);

export const PageHead = ({ title, children }) => (
  <div className="pb-2 pt-8">
    <h1 className="text-3xl font-extrabold sm:text-4xl">{title}</h1>
    {children && <p className="mt-2 max-w-2xl text-muted">{children}</p>}
  </div>
);
