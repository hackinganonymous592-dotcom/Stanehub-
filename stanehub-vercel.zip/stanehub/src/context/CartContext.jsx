import { createContext, useContext, useEffect, useMemo, useState } from "react";

const Ctx = createContext(null);
export const useCart = () => useContext(Ctx);

const load = () => {
  try {
    return JSON.parse(localStorage.getItem("stanehub_cart")) || [];
  } catch {
    return [];
  }
};

export function CartProvider({ children }) {
  const [items, setItems] = useState(load);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem("stanehub_cart", JSON.stringify(items));
    } catch {}
  }, [items]);

  const api = useMemo(() => {
    const key = (i) => i.productId + "|" + i.variant;
    return {
      items,
      open,
      setOpen,
      count: items.reduce((a, i) => a + i.qty, 0),
      subtotal: items.reduce((a, i) => a + i.price * i.qty, 0),
      add(product, variant, qty = 1) {
        const v = product.variants[variant];
        setItems((cur) => {
          const found = cur.find((i) => i.productId === product.id && i.variant === variant);
          if (found) return cur.map((i) => (i === found ? { ...i, qty: Math.min(20, i.qty + qty) } : i));
          return [...cur, { productId: product.id, slug: product.slug, name: product.name, color: product.color, initials: product.initials, variant, option: v.label, price: v.price, qty }];
        });
      },
      setQty(it, qty) {
        setItems((cur) => (qty < 1 ? cur.filter((i) => key(i) !== key(it)) : cur.map((i) => (key(i) === key(it) ? { ...i, qty: Math.min(20, qty) } : i))));
      },
      remove(it) {
        setItems((cur) => cur.filter((i) => key(i) !== key(it)));
      },
      clear() {
        setItems([]);
      },
    };
  }, [items, open]);

  return <Ctx.Provider value={api}>{children}</Ctx.Provider>;
}
