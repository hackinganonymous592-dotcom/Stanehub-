import { createContext, useContext, useEffect, useState } from "react";
import { supabase } from "../lib/supabase";

const DEFAULTS = {
  shop_name: "StaneHub",
  whatsapp: "22600000000",
  pay_methods: { "Orange Money": "+226 00 00 00 00", "Moov Money": "+226 00 00 00 00", Wave: "+226 00 00 00 00" },
  tpl_order: "Bonjour, commande {id} de {nom} : {produits}. Total {total}.",
  tpl_delivered: "Bonjour {nom}, ta commande {id} est livrée : {produits}.",
  tpl_relance: "Bonjour {nom}, ta commande {id} ({total}) attend ton paiement.",
};

const Ctx = createContext({ settings: DEFAULTS, reload: () => {} });
export const useSettings = () => useContext(Ctx);

export function SettingsProvider({ children }) {
  const [settings, setSettings] = useState(DEFAULTS);
  const load = () =>
    supabase
      .from("settings")
      .select("key, value")
      .then(({ data }) => {
        if (!data) return;
        const o = { ...DEFAULTS };
        data.forEach((r) => (o[r.key] = r.value));
        setSettings(o);
      });
  useEffect(() => {
    load();
  }, []);
  return <Ctx.Provider value={{ settings, reload: load }}>{children}</Ctx.Provider>;
}
