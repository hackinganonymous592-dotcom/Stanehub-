import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import { CartProvider } from "./context/CartContext";
import { SettingsProvider } from "./context/SettingsContext";
import { isConfigured } from "./lib/supabase";
import "./index.css";

function Missing() {
  return (
    <div className="grid min-h-screen place-items-center p-6">
      <div className="card max-w-lg space-y-3 p-6">
        <h1 className="text-2xl font-extrabold">Configuration manquante</h1>
        <p>
          Ajoute <code>VITE_SUPABASE_URL</code> et <code>VITE_SUPABASE_ANON_KEY</code> dans le fichier <code>.env</code> (en local) ou dans les variables
          d'environnement de Vercel, puis relance.
        </p>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    {isConfigured ? (
      <BrowserRouter>
        <SettingsProvider>
          <CartProvider>
            <App />
          </CartProvider>
        </SettingsProvider>
      </BrowserRouter>
    ) : (
      <Missing />
    )}
  </React.StrictMode>
);
