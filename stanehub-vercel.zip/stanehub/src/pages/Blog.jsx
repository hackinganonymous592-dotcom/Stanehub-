import { Link, useParams } from "react-router-dom";
import { getPost, getPosts } from "../lib/api";
import { useAsync } from "../lib/useAsync";
import { Empty, ErrorBox, PageHead, Spinner } from "../components/ui";
import { dlong } from "../lib/format";

export function Blog() {
  const res = useAsync(() => getPosts());
  return (
    <div className="wrap pb-8">
      <PageHead title="Blog">Guides, comparatifs et actualités sur les abonnements numériques.</PageHead>
      <div className="grid gap-4 pt-4 sm:grid-cols-2 lg:grid-cols-3">
        {res.loading ? <Spinner /> : (res.data || []).length === 0 ? <Empty>Aucun article pour le moment.</Empty> : res.data.map((p) => (
          <Link key={p.id} to={`/blog/${p.slug}`} className="card grid content-start gap-2 p-5 transition hover:border-teal">
            <span className="text-sm text-muted">{dlong(p.created_at)}</span>
            <h2 className="text-lg font-bold">{p.title}</h2>
            <p className="text-sm text-muted">{p.excerpt}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}

export function Post() {
  const { slug } = useParams();
  const { data: p, loading, error } = useAsync(() => getPost(slug), [slug]);
  if (loading) return <Spinner />;
  if (error) return <div className="wrap py-8"><ErrorBox error={error} /></div>;
  if (!p) return <div className="wrap py-8"><Empty cta={{ to: "/blog", label: "Retour au blog" }}>Cet article n'existe plus.</Empty></div>;
  return (
    <div className="wrap pb-8">
      <p className="pt-6 text-sm"><Link to="/blog" className="text-teal hover:underline">Blog</Link></p>
      <PageHead title={p.title}>{dlong(p.created_at)}</PageHead>
      <article className="max-w-2xl space-y-4 pt-4 text-[17px] leading-relaxed">
        {p.body.split("\n").filter(Boolean).map((x, i) => <p key={i}>{x}</p>)}
      </article>
    </div>
  );
}
