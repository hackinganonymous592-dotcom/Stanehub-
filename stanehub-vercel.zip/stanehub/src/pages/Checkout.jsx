import { useState } from "react";
import { Link } from "react-router-dom";
import { useCart } from "../context/CartContext";
import { useSettings } from "../context/SettingsContext";
import { checkCoupon, createOrder, uploadProof } from "../lib/api";
import { Logo, PageHead } from "../components/ui";
import { digits, fill, fmt, waLink } from "../lib/format";

const loadProfile = () => {
  try { return JSON.parse(localStorage.getItem("stanehub_profile")) || {}; } catch { return {}; }
};

export default function Checkout() {
  const cart = useCart();
  const { settings } = useSettings();
  const methods = Object.keys(settings.pay_methods || {});
  const [form, setForm] = useState(() => ({ name: loadProfile().name || "", phone: loadProfile().phone || "", method: "" }));
  const [file, setFile] = useState(null);
  const [code, setCode] = useState("");
  const [coupon, setCoupon] = useState(null); // {code, discount}
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(null);

  const method = form.method || methods[0] || "";
  const discount = coupon ? Math.min(coupon.discount, cart.subtotal) : 0;
  const total = cart.subtotal - discount;

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function applyCoupon() {
    setErr("");
    if (!code.trim()) return setCoupon(null);
    try {
      const r = await checkCoupon(code.trim(), cart.subtotal);
      if (r.valid) setCoupon({ code: r.code, discount: r.discount });
      else { setCoupon(null); setErr("Ce code n'existe pas ou n'est plus actif."); }
    } catch (e) { setErr(e.message); }
  }

  async function submit(e) {
    e.preventDefault();
    setErr("");
    if (form.name.trim().length < 2) return setErr("Entre ton nom.");
    if (digits(form.phone).length < 8) return setErr("Entre un numéro WhatsApp valide, avec l'indicatif.");
    if (!file) return setErr("Ajoute la capture de ton paiement pour continuer.");
    setBusy(true);
    try {
      const proof = await uploadProof(file);
      const r = await createOrder({ name: form.name, phone: form.phone, items: cart.items, coupon: coupon?.code, method, proof });
      try {
        localStorage.setItem("stanehub_profile", JSON.stringify({ name: form.name, phone: form.phone }));
        const codes = JSON.parse(localStorage.getItem("stanehub_orders") || "[]");
        localStorage.setItem("stanehub_orders", JSON.stringify([r.code, ...codes]));
      } catch {}
      cart.clear();
      setDone(r);
    } catch (e2) {
      setErr(e2.message);
    } finally {
      setBusy(false);
    }
  }

  if (done) {
    const msg = fill(settings.tpl_order, {
      id: done.code,
      nom: form.name,
      produits: done.items.map((i) => `${i.name} ${i.option}${i.qty > 1 ? " x" + i.qty : ""}`).join(", "),
      total: fmt(done.total),
    }) + `\nPaiement : ${method}`;
    return (
      <div className="wrap max-w-xl py-10">
        <div className="card grid gap-4 p-6 text-center">
          <h1 className="text-3xl font-extrabold">Commande {done.code} enregistrée</h1>
          <p className="text-muted">On vérifie ton paiement, puis on te livre sur WhatsApp. Envoie le message ci-dessous pour accélérer le traitement.</p>
          <a className="btn" href={waLink(settings.whatsapp, msg)} target="_blank" rel="noreferrer">Envoyer sur WhatsApp</a>
          <Link className="btn btn-line" to="/commandes">Suivre ma commande</Link>
        </div>
      </div>
    );
  }

  if (cart.items.length === 0)
    return (
      <div className="wrap py-10">
        <div className="grid justify-items-center gap-3 rounded-2xl border border-dashed border-line p-10 text-center text-muted">
          <p>Ton panier est vide.</p>
          <Link className="btn" to="/produits">Voir les produits</Link>
        </div>
      </div>
    );

  return (
    <div className="wrap pb-8">
      <PageHead title="Finaliser la commande">Remplis tes infos, paie par mobile money et ajoute la capture du paiement.</PageHead>
      <form onSubmit={submit} className="grid gap-5 pt-4 lg:grid-cols-[1fr_380px]">
        <div className="grid content-start gap-5">
          <section className="card grid gap-4 p-5">
            <h2 className="text-xl font-extrabold">1. Tes informations</h2>
            <label className="grid gap-1.5 text-sm font-semibold">Nom<input className="input" autoComplete="name" value={form.name} onChange={set("name")} /></label>
            <label className="grid gap-1.5 text-sm font-semibold">Numéro WhatsApp<input className="input" inputMode="tel" autoComplete="tel" placeholder="+226 ..." value={form.phone} onChange={set("phone")} /></label>
            <p className="text-sm text-muted">Ton accès te sera envoyé sur ce numéro. Pour une recharge de jeu, écris ton ID joueur dans le message WhatsApp qui suit.</p>
          </section>
          <section className="card grid gap-4 p-5">
            <h2 className="text-xl font-extrabold">2. Paiement</h2>
            <div className="grid gap-2" role="radiogroup" aria-label="Moyen de paiement">
              {methods.map((m) => (
                <label key={m} className="flex min-h-[48px] cursor-pointer items-center gap-3 rounded-xl border border-line bg-bg px-3">
                  <input type="radio" name="method" className="h-5 w-5 accent-[#FF8000]" checked={method === m} onChange={() => setForm((f) => ({ ...f, method: m }))} /> {m}
                </label>
              ))}
            </div>
            <div className="rounded-xl bg-soft p-4 text-sm">
              Envoie <b>{fmt(total)}</b> par {method} au <b>{settings.pay_methods?.[method]}</b>, puis ajoute la capture du paiement.
            </div>
            <label className="grid gap-1.5 text-sm font-semibold">Preuve de paiement
              <input className="input" type="file" accept="image/*" onChange={(e) => setFile(e.target.files?.[0] || null)} />
            </label>
            {file && <img alt="Aperçu de ta preuve de paiement" src={URL.createObjectURL(file)} className="max-h-48 w-fit rounded-xl border border-line object-contain" />}
          </section>
        </div>

        <aside className="card grid h-fit content-start gap-3 p-5 lg:sticky lg:top-24">
          <h2 className="text-xl font-extrabold">Récapitulatif</h2>
          {cart.items.map((it) => (
            <div key={it.productId + it.variant} className="flex items-center gap-3">
              <Logo p={it} size={40} />
              <div className="min-w-0 flex-1"><b className="block truncate">{it.name}</b><span className="text-sm text-muted">{it.option} × {it.qty}</span></div>
              <b>{fmt(it.price * it.qty)}</b>
            </div>
          ))}
          <div className="flex gap-2">
            <input className="input" placeholder="Code promo" value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} aria-label="Code promo" />
            <button type="button" className="btn btn-line" onClick={applyCoupon}>Appliquer</button>
          </div>
          <div className="flex justify-between"><span>Sous-total</span><span>{fmt(cart.subtotal)}</span></div>
          {coupon && <div className="flex justify-between text-teal"><span>Code {coupon.code}</span><span>−{fmt(discount)}</span></div>}
          <div className="flex justify-between text-2xl font-extrabold"><span>Total</span><span>{fmt(total)}</span></div>
          {err && <p role="alert" className="text-sm font-semibold text-red-600 dark:text-red-400">{err}</p>}
          <button className="btn w-full" disabled={busy}>{busy ? "Envoi en cours..." : "Confirmer la commande"}</button>
          <p className="text-xs text-muted">Le prix final est recalculé par la boutique au moment de la commande.</p>
        </aside>
      </form>
    </div>
  );
}
