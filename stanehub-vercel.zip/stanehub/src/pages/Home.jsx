import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Search, Zap, Smartphone, ShieldCheck } from "lucide-react";
import { getCategories, getPosts, getProducts, getTestimonials } from "../lib/api";
import { useAsync } from "../lib/useAsync";
import ProductCard from "../components/ProductCard";
import { Spinner, SectionHead } from "../components/ui";
import { dlong } from "../lib/format";
import { FAQ_ITEMS, FaqList } from "./Info";

export default function Home() {
  const nav = useNavigate();
  const [q, setQ] = useState("");
  const cats = useAsync(getCategories);
  const feat = useAsync(() => getProducts({ featured: true, pack: false }));
  const packs = useAsync(() => getProducts({ pack: true }));
  const games = useAsync(async () => {
    const c = (await getCategories()).find((x) => x.name === "Jeux");
    return c ? getProducts({ category: c.id }) : [];
  });
  const tmo = useAsync(getTestimonials);
  const posts = useAsync(() => getPosts(3));
  const tiles = (feat.data || []).slice(0, 9);

  return (
    <>
      <section className="rounded-b-[32px] bg-gradient-to-br from-navy to-navy2 py-12 text-white sm:py-20">
        <div className="wrap grid items-center gap-10 lg:grid-cols-[1.2fr_.8fr]">
          <div>
            <h1 className="max-w-[16ch] text-4xl font-extrabold leading-[1.05] sm:text-6xl">Abonnements numériques au meilleur prix.</h1>
            <p className="mt-4 max-w-xl text-lg text-slate-300">
              Streaming, musique, IA, recharges de jeux et cartes cadeaux. Tu paies par mobile money, on te livre sur WhatsApp.
            </p>
            <form
              className="mt-6 flex max-w-xl gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                nav(`/produits?q=${encodeURIComponent(q)}`);
              }}
            >
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                type="search"
                placeholder="Netflix, Spotify, Free Fire..."
                aria-label="Rechercher un produit"
                className="min-h-[52px] min-w-0 flex-1 rounded-xl border-0 bg-white px-4 text-slate-900"
              />
              <button className="btn" aria-label="Rechercher">
                <Search size={20} />
                <span className="hidden sm:inline">Chercher</span>
              </button>
            </form>
            <ul className="mt-5 flex flex-wrap gap-2 text-sm font-semibold">
              {[[Zap, "Livraison sur WhatsApp"], [Smartphone, "Orange Money, Moov, Wave"], [ShieldCheck, "Support sous 48 h"]].map(([Icon, t]) => (
                <li key={t} className="flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1.5">
                  <Icon size={15} /> {t}
                </li>
              ))}
            </ul>
          </div>
          <div className="hidden grid-cols-3 gap-3 lg:grid" aria-hidden="true">
            {tiles.map((p, i) => (
              <Link key={p.id} tabIndex={-1} to={`/produit/${p.slug}`} className={"grid aspect-square place-items-center rounded-3xl text-3xl font-extrabold shadow-2xl " + (i % 2 ? "translate-y-4" : "")} style={{ background: p.color }}>
                {p.initials}
              </Link>
            ))}
          </div>
        </div>
      </section>

      <div className="wrap space-y-12 pt-10">
        <section>
          <SectionHead title="Catégories" />
          {cats.loading ? <Spinner /> : (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
              {(cats.data || []).map((c) => (
                <Link key={c.id} to={`/produits?c=${c.id}`} className="card grid gap-1 p-4 transition hover:-translate-y-0.5 hover:border-teal">
                  <span className="text-3xl">{c.emoji}</span>
                  <b>{c.name}</b>
                </Link>
              ))}
            </div>
          )}
        </section>

        <Block title="Les plus demandés" to="/produits" res={feat} />
        {(packs.data || []).length > 0 && <Block title="Packs économiques" to="/packs" label="Tous les packs" res={packs} />}
        {(games.data || []).length > 0 && <Block title="Recharges de jeux" to="/produits" label="Voir le catalogue" res={games} />}

        <section>
          <SectionHead title="Comment ça marche" />
          <ol className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[["Choisis ton produit", "Sélectionne la durée ou le montant qui te convient."], ["Remplis tes infos", "Ton nom et ton numéro WhatsApp pour la livraison."], ["Paie en mobile money", "Envoie le montant et ajoute la capture du paiement."], ["Reçois ton accès", "On vérifie et on te livre sur WhatsApp."]].map(([t, d], i) => (
              <li key={t} className="card p-4">
                <span className="mb-2 grid h-8 w-8 place-items-center rounded-full bg-primary font-extrabold text-[#1B1204]">{i + 1}</span>
                <b>{t}</b>
                <p className="text-sm text-muted">{d}</p>
              </li>
            ))}
          </ol>
        </section>

        <section className="grid gap-3 rounded-3xl bg-gradient-to-br from-teal to-[#0A5F78] p-6 text-white sm:p-8">
          <h2 className="text-2xl font-extrabold sm:text-3xl">Deviens revendeur et achète au prix de gros</h2>
          <p className="max-w-2xl text-white/90">Tu fixes ton prix de vente et tu gardes la différence. Envoie ta demande, on la valide avec ton numéro WhatsApp.</p>
          <Link to="/revendeur" className="btn w-fit">Devenir revendeur</Link>
        </section>

        {(tmo.data || []).length > 0 && (
          <section>
            <SectionHead title="Avis clients" to="/temoignages" label="Tous les avis" />
            <div className="grid gap-3 sm:grid-cols-3">
              {tmo.data.slice(0, 3).map((t) => (
                <div key={t.id} className="card grid gap-2 p-4">
                  <p>{t.text}</p>
                  <b>{t.name}</b>
                  <span className="text-sm text-muted">{t.city}</span>
                </div>
              ))}
            </div>
          </section>
        )}

        {(posts.data || []).length > 0 && (
          <section>
            <SectionHead title="Au fil du blog" to="/blog" label="Tous les articles" />
            <div className="grid gap-3 sm:grid-cols-3">
              {posts.data.map((p) => (
                <Link key={p.id} to={`/blog/${p.slug}`} className="card grid content-start gap-2 p-4 transition hover:border-teal">
                  <span className="text-sm text-muted">{dlong(p.created_at)}</span>
                  <h3 className="text-lg font-bold">{p.title}</h3>
                  <p className="text-sm text-muted">{p.excerpt}</p>
                </Link>
              ))}
            </div>
          </section>
        )}

        <section>
          <SectionHead title="Questions fréquentes" to="/faq" label="Toute la FAQ" />
          <FaqList items={FAQ_ITEMS.slice(0, 3)} />
        </section>
      </div>
    </>
  );
}

function Block({ title, to, label, res }) {
  return (
    <section>
      <SectionHead title={title} to={to} label={label} />
      {res.loading ? <Spinner /> : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {(res.data || []).slice(0, 8).map((p) => (
            <ProductCard key={p.id} p={p} />
          ))}
        </div>
      )}
    </section>
  );
}
