import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { getTestimonials } from "../lib/api";
import { useAsync } from "../lib/useAsync";
import { Empty, PageHead, Spinner } from "../components/ui";
import { useSettings } from "../context/SettingsContext";
import { waLink } from "../lib/format";

export const FAQ_ITEMS = [
  ["Comment commander ?", "Ajoute un produit au panier, remplis ton nom et ton numéro WhatsApp, paie avec ton mobile money puis ajoute la capture du paiement. On vérifie et on te livre l'accès sur WhatsApp."],
  ["Combien de temps prend la livraison ?", "Dès que le paiement est vérifié, la livraison se fait en quelques minutes pendant nos heures d'ouverture. L'état de ta commande est visible dans Mes commandes."],
  ["Quels moyens de paiement acceptez-vous ?", "Orange Money, Moov Money et Wave."],
  ["Que faire si l'accès ne marche pas ?", "Signale le problème dans les 48 heures suivant la livraison, avec ton numéro de commande. Le compte est remplacé ou remboursé."],
  ["Comment fonctionne la recharge de jeux ?", "Tu donnes ton ID joueur dans le message WhatsApp de ta commande. On recharge ton compte et on te confirme."],
  ["Comment devenir revendeur ?", "Va dans la page Revendeur et envoie ta demande. Après validation, tu reçois tes tarifs de gros."],
];

export function FaqList({ items = FAQ_ITEMS }) {
  return (
    <div className="grid gap-2">
      {items.map(([q, a]) => (
        <details key={q} className="card group px-4">
          <summary className="flex min-h-[52px] cursor-pointer items-center font-bold">{q}</summary>
          <p className="pb-4 text-muted">{a}</p>
        </details>
      ))}
    </div>
  );
}

export const Faq = () => (
  <div className="wrap pb-8">
    <PageHead title="Questions fréquentes">Activation, paiement et livraison.</PageHead>
    <div className="pt-4"><FaqList /></div>
  </div>
);

export function Contact() {
  const { settings } = useSettings();
  const [msg, setMsg] = useState("");
  return (
    <div className="wrap pb-8">
      <PageHead title="Contact">Une question ? On répond sur WhatsApp, tous les jours.</PageHead>
      <div className="grid gap-5 pt-4 md:grid-cols-2">
        <div className="card grid gap-3 p-5">
          <h2 className="text-xl font-extrabold">Écrire sur WhatsApp</h2>
          <textarea className="input min-h-[120px]" placeholder="Bonjour, ..." value={msg} onChange={(e) => setMsg(e.target.value)} aria-label="Ton message" />
          <a className="btn" target="_blank" rel="noreferrer" href={waLink(settings.whatsapp, msg || "Bonjour")}>Ouvrir WhatsApp</a>
        </div>
        <div className="card grid content-start gap-3 p-5">
          <h2 className="text-xl font-extrabold">Avant d'écrire</h2>
          <p className="text-muted">Pour un problème d'accès, indique ton numéro de commande. Tu as 48 heures après la livraison pour le signaler.</p>
          <Link to="/faq" className="btn btn-line w-fit">Voir la FAQ</Link>
        </div>
      </div>
    </div>
  );
}

const LEGAL = {
  conditions: ["Conditions d'utilisation", "Les comptes sont fournis pour un usage personnel. Le partage des identifiants en dehors de ta commande peut entraîner la suspension de l'accès sans remboursement. Les prix peuvent changer sans préavis."],
  confidentialite: ["Confidentialité", "Ton nom et ton numéro WhatsApp servent uniquement à traiter ta commande et à te livrer. Ils ne sont ni revendus ni partagés."],
  remboursement: ["Politique de remboursement", "Signale tout problème au support dans les 48 heures suivant la livraison, avec ton numéro de commande. Le compte est remplacé, ou remboursé si le remplacement est impossible."],
};

export function Legal() {
  const { slug } = useParams();
  const l = LEGAL[slug] || LEGAL.conditions;
  return (
    <div className="wrap pb-8">
      <PageHead title={l[0]} />
      <p className="max-w-2xl pt-4 text-[17px] leading-relaxed">{l[1]}</p>
    </div>
  );
}

export function Testimonials() {
  const res = useAsync(getTestimonials);
  return (
    <div className="wrap pb-8">
      <PageHead title="Témoignages" />
      <div className="grid gap-3 pt-4 sm:grid-cols-2 lg:grid-cols-3">
        {res.loading ? <Spinner /> : (res.data || []).length === 0 ? <Empty>Aucun avis pour le moment.</Empty> : res.data.map((t) => (
          <div key={t.id} className="card grid gap-2 p-4"><p>{t.text}</p><b>{t.name}</b><span className="text-sm text-muted">{t.city}</span></div>
        ))}
      </div>
    </div>
  );
}

export const NotFound = () => (
  <div className="wrap py-14">
    <Empty cta={{ to: "/", label: "Retour à l'accueil" }}>Cette page n'existe pas.</Empty>
  </div>
);
