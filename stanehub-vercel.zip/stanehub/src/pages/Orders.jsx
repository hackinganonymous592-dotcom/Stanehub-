import { useState } from "react";
import { trackOrders } from "../lib/api";
import { useAsync } from "../lib/useAsync";
import { Empty, PageHead, Spinner, StatusTag } from "../components/ui";
import { useSettings } from "../context/SettingsContext";
import { dstr, fmt, waLink } from "../lib/format";

const getCodes = () => {
  try { return JSON.parse(localStorage.getItem("stanehub_orders") || "[]"); } catch { return []; }
};

export default function Orders() {
  const { settings } = useSettings();
  const [codes, setCodes] = useState(getCodes);
  const [manual, setManual] = useState("");
  const res = useAsync(() => (codes.length ? trackOrders(codes) : []), [codes.join(",")]);

  function add(e) {
    e.preventDefault();
    const c = manual.trim().toUpperCase();
    if (!c) return;
    const next = [c, ...codes.filter((x) => x !== c)];
    setCodes(next);
    try { localStorage.setItem("stanehub_orders", JSON.stringify(next)); } catch {}
    setManual("");
  }

  return (
    <div className="wrap pb-8">
      <PageHead title="Mes commandes">Suis le paiement et la livraison de tes achats.</PageHead>
      <form onSubmit={add} className="mt-4 flex max-w-md gap-2">
        <input className="input" placeholder="Ajouter un numéro de commande (SH-XXXXXX)" value={manual} onChange={(e) => setManual(e.target.value)} aria-label="Numéro de commande" />
        <button className="btn btn-line">Ajouter</button>
      </form>
      <div className="mt-5 grid gap-3">
        {res.loading ? <Spinner /> : (res.data || []).length === 0 ? (
          <Empty cta={{ to: "/produits", label: "Voir les produits" }}>Aucune commande à afficher sur cet appareil.</Empty>
        ) : (
          res.data.map((o) => (
            <div key={o.code} className="card grid gap-2 p-4">
              <div className="flex items-center justify-between"><b>{o.code}</b><StatusTag s={o.status} /></div>
              <div className="text-sm text-muted">{dstr(o.created_at)} · {o.method}</div>
              {o.items.map((i, k) => (
                <div key={k} className="flex justify-between"><span>{i.name}, {i.option} × {i.qty}</span><span>{fmt(i.total)}</span></div>
              ))}
              <div className="flex justify-between font-extrabold"><span>Total</span><span>{fmt(o.total)}</span></div>
              <a className="btn btn-line btn-sm w-fit" target="_blank" rel="noreferrer" href={waLink(settings.whatsapp, "Bonjour, commande " + o.code)}>Écrire sur WhatsApp</a>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
