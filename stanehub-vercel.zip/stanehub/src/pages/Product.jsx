import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Check } from "lucide-react";
import { getProduct } from "../lib/api";
import { useAsync } from "../lib/useAsync";
import { useCart } from "../context/CartContext";
import { Empty, ErrorBox, Spinner } from "../components/ui";
import { fmt } from "../lib/format";

export default function Product() {
  const { slug } = useParams();
  const nav = useNavigate();
  const cart = useCart();
  const { data: p, loading, error } = useAsync(() => getProduct(slug), [slug]);
  const [vi, setVi] = useState(0);
  useEffect(() => setVi(0), [slug]);

  if (loading) return <Spinner />;
  if (error) return <div className="wrap py-8"><ErrorBox error={error} /></div>;
  if (!p) return <div className="wrap py-8"><Empty cta={{ to: "/produits", label: "Voir les produits" }}>Ce produit n'existe plus.</Empty></div>;

  const v = p.variants[vi] || p.variants[0];
  const out = p.stock === 0;
  return (
    <div className="wrap py-6">
      <p className="text-sm text-muted">
        <Link to="/produits" className="hover:underline">Produits</Link> / {p.categories?.name || "Packs"}
      </p>
      <div className="grid gap-8 py-5 md:grid-cols-2">
        <div className="grid aspect-[16/10] place-items-center rounded-3xl text-7xl font-extrabold text-white shadow-card" style={{ background: p.color }} aria-hidden="true">
          {p.initials}
        </div>
        <div className="grid content-start gap-4">
          <div>
            <h1 className="text-3xl font-extrabold sm:text-4xl">{p.name}</h1>
            <p className="mt-2 text-muted">{p.description}</p>
          </div>
          {p.is_pack && p.includes && (
            <ul className="grid gap-1.5">
              {p.includes.split("\n").filter(Boolean).map((i) => (
                <li key={i} className="flex items-center gap-2"><Check size={17} className="text-teal" /> {i}</li>
              ))}
            </ul>
          )}
          <div className="flex flex-wrap gap-2" role="group" aria-label="Choisir une option">
            {p.variants.map((x, i) => (
              <button key={x.label} className="chip" aria-pressed={i === vi} onClick={() => setVi(i)}>{x.label}</button>
            ))}
          </div>
          <div className="text-4xl font-extrabold">{fmt(v.price)}</div>
          {out && <span className="tag w-fit bg-red-100 text-red-800">Rupture de stock</span>}
          <div className="flex flex-wrap gap-2">
            <button className="btn" disabled={out} onClick={() => { cart.add(p, vi); cart.setOpen(true); }}>Ajouter au panier</button>
            <button className="btn btn-teal" disabled={out} onClick={() => { cart.add(p, vi); nav("/commande"); }}>Acheter maintenant</button>
          </div>
          <ul className="grid gap-1.5 text-sm text-muted">
            <li className="flex items-center gap-2"><Check size={16} /> Livraison sur WhatsApp après vérification du paiement</li>
            <li className="flex items-center gap-2"><Check size={16} /> Problème signalé sous 48 h : remplacé ou remboursé</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
