import { useSearchParams } from "react-router-dom";
import { getCategories, getProducts } from "../lib/api";
import { useAsync } from "../lib/useAsync";
import ProductCard from "../components/ProductCard";
import { Empty, ErrorBox, PageHead, Spinner } from "../components/ui";

export default function Products({ packs = false }) {
  const [params, setParams] = useSearchParams();
  const cat = params.get("c") || "";
  const q = params.get("q") || "";
  const cats = useAsync(getCategories);
  const list = useAsync(() => getProducts({ category: packs ? undefined : cat || undefined, search: q || undefined, pack: packs ? true : undefined }), [cat, q, packs]);

  const set = (k, v) => {
    const n = new URLSearchParams(params);
    v ? n.set(k, v) : n.delete(k);
    setParams(n, { replace: true });
  };

  return (
    <div className="wrap pb-6">
      <PageHead title={packs ? "Packs" : "Produits"}>{packs ? "Plusieurs services ensemble, moins cher que séparément." : "Abonnements, recharges de jeux et cartes cadeaux."}</PageHead>
      {!packs && (
        <div className="space-y-3 py-4">
          <input className="input" type="search" placeholder="Rechercher un produit" aria-label="Rechercher un produit" value={q} onChange={(e) => set("q", e.target.value)} />
          <div className="flex gap-2 overflow-x-auto pb-1">
            <button className="chip shrink-0" aria-pressed={!cat} onClick={() => set("c", "")}>
              Tous
            </button>
            {(cats.data || []).map((c) => (
              <button key={c.id} className="chip shrink-0" aria-pressed={cat === c.id} onClick={() => set("c", c.id)}>
                {c.emoji} {c.name}
              </button>
            ))}
          </div>
        </div>
      )}
      {list.loading ? <Spinner /> : list.error ? <ErrorBox error={list.error} /> : (list.data || []).length === 0 ? (
        <Empty>Aucun résultat{q ? ` pour « ${q} »` : ""}.</Empty>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {list.data.map((p) => (
            <ProductCard key={p.id} p={p} />
          ))}
        </div>
      )}
    </div>
  );
}
