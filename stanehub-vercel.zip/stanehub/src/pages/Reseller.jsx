import { useState } from "react";
import { Check } from "lucide-react";
import { submitReseller } from "../lib/api";
import { PageHead } from "../components/ui";
import { useSettings } from "../context/SettingsContext";
import { digits, waLink } from "../lib/format";

export default function Reseller() {
  const { settings } = useSettings();
  const [f, setF] = useState({ name: "", phone: "", city: "" });
  const [state, setState] = useState({ busy: false, err: "", ok: false });
  const set = (k) => (e) => setF((x) => ({ ...x, [k]: e.target.value }));

  async function send(e) {
    e.preventDefault();
    if (f.name.trim().length < 2 || digits(f.phone).length < 8) return setState({ busy: false, ok: false, err: "Entre ton nom et un numéro WhatsApp valide." });
    setState({ busy: true, err: "", ok: false });
    try {
      await submitReseller({ name: f.name.trim(), phone: f.phone.trim(), city: f.city.trim() || null });
      setState({ busy: false, err: "", ok: true });
    } catch (e2) {
      setState({ busy: false, err: e2.message, ok: false });
    }
  }

  return (
    <div className="wrap pb-8">
      <PageHead title="Devenir revendeur">Achète au prix de gros et revends au prix de ton choix. Tu gardes la différence sur chaque vente.</PageHead>
      <div className="grid gap-5 pt-4 md:grid-cols-2">
        <div className="card grid content-start gap-3 p-5">
          <h2 className="text-xl font-extrabold">Comment ça marche</h2>
          {["Tu envoies ta demande", "On la valide avec ton numéro WhatsApp", "Tu reçois tes tarifs de gros", "Tu revends au prix que tu fixes"].map((t) => (
            <p key={t} className="flex items-center gap-2"><Check size={18} className="text-teal" /> {t}</p>
          ))}
        </div>
        <form onSubmit={send} className="card grid content-start gap-4 p-5">
          {state.ok ? (
            <>
              <h2 className="text-xl font-extrabold">Demande envoyée</h2>
              <p className="text-muted">On te répond sur WhatsApp après étude de ta demande.</p>
              <a className="btn" target="_blank" rel="noreferrer" href={waLink(settings.whatsapp, `Bonjour, je viens d'envoyer ma demande de revendeur.\nNom : ${f.name}\nWhatsApp : ${f.phone}`)}>Prévenir sur WhatsApp</a>
            </>
          ) : (
            <>
              <h2 className="text-xl font-extrabold">Ma demande</h2>
              <label className="grid gap-1.5 text-sm font-semibold">Nom<input className="input" autoComplete="name" value={f.name} onChange={set("name")} /></label>
              <label className="grid gap-1.5 text-sm font-semibold">Numéro WhatsApp<input className="input" inputMode="tel" placeholder="+226 ..." value={f.phone} onChange={set("phone")} /></label>
              <label className="grid gap-1.5 text-sm font-semibold">Ville<input className="input" value={f.city} onChange={set("city")} /></label>
              {state.err && <p role="alert" className="text-sm font-semibold text-red-600 dark:text-red-400">{state.err}</p>}
              <button className="btn" disabled={state.busy}>{state.busy ? "Envoi..." : "Envoyer ma demande"}</button>
            </>
          )}
        </form>
      </div>
    </div>
  );
}
