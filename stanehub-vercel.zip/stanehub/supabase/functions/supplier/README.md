Le code de cette fonction est déployé sur le projet Supabase « Stanehub » (fonction `supplier`).
Pour le récupérer ou le modifier : Supabase > Edge Functions > supplier.
Secret requis : GALAXY_API_KEY.
