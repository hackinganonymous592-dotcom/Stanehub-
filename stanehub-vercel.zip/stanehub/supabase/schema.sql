-- =====================================================================
-- StaneHub : schéma Supabase (tables, sécurité RLS, fonctions, données de départ)
-- À coller en entier dans Supabase > SQL Editor > Run
-- =====================================================================
create extension if not exists pgcrypto;

-- ---------- Tables ----------
create table if not exists categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  emoji text not null default '🛍',
  position int not null default 0
);

create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  category_id uuid references categories(id) on delete set null,
  description text not null default '',
  color text not null default '#2563EB',
  initials text not null default '',
  variants jsonb not null default '[]',        -- [{"label":"1 mois","price":3500}]
  stock int not null default -1,               -- -1 = illimité
  featured boolean not null default false,
  active boolean not null default true,
  is_pack boolean not null default false,
  includes text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists coupons (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  kind text not null default 'pct' check (kind in ('pct','flat')),
  value int not null check (value > 0),
  active boolean not null default true
);

create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  customer_name text not null,
  customer_phone text not null,
  items jsonb not null,
  subtotal int not null,
  discount int not null default 0,
  total int not null,
  coupon text,
  method text not null,
  proof_path text,
  status text not null default 'pending' check (status in ('pending','paid','delivered','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists reseller_requests (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text not null,
  city text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

create table if not exists testimonials (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  city text not null default '',
  text text not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists posts (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  title text not null,
  excerpt text not null default '',
  body text not null default '',
  published boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists settings (
  key text primary key,
  value jsonb not null
);

create table if not exists admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);

-- ---------- Fonction admin ----------
create or replace function is_admin() returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from admins where user_id = auth.uid())
$$;
grant execute on function is_admin() to anon, authenticated;

-- ---------- Sécurité (RLS) ----------
alter table categories enable row level security;
alter table products enable row level security;
alter table coupons enable row level security;
alter table orders enable row level security;
alter table reseller_requests enable row level security;
alter table testimonials enable row level security;
alter table posts enable row level security;
alter table settings enable row level security;
alter table admins enable row level security;

create policy "public read categories" on categories for select using (true);
create policy "public read products" on products for select using (active or is_admin());
create policy "public read testimonials" on testimonials for select using (active or is_admin());
create policy "public read posts" on posts for select using (published or is_admin());
create policy "public read settings" on settings for select using (true);
create policy "public create reseller request" on reseller_requests for insert with check (true);

create policy "admin all categories" on categories for all using (is_admin()) with check (is_admin());
create policy "admin all products" on products for all using (is_admin()) with check (is_admin());
create policy "admin all coupons" on coupons for all using (is_admin()) with check (is_admin());
create policy "admin all orders" on orders for all using (is_admin()) with check (is_admin());
create policy "admin all reseller" on reseller_requests for all using (is_admin()) with check (is_admin());
create policy "admin all testimonials" on testimonials for all using (is_admin()) with check (is_admin());
create policy "admin all posts" on posts for all using (is_admin()) with check (is_admin());
create policy "admin all settings" on settings for all using (is_admin()) with check (is_admin());
create policy "admin read admins" on admins for select using (user_id = auth.uid());

-- ---------- Création de commande (prix calculés côté serveur) ----------
create or replace function create_order(
  p_name text, p_phone text, p_items jsonb, p_coupon text, p_method text, p_proof text
) returns json
language plpgsql security definer set search_path = public as $$
declare
  it jsonb; pr products%rowtype; v jsonb; q int; line jsonb;
  lines jsonb := '[]'::jsonb; sub int := 0; disc int := 0; tot int;
  c coupons%rowtype; ocode text;
begin
  if length(trim(coalesce(p_name,''))) < 2 or length(regexp_replace(coalesce(p_phone,''),'\D','','g')) < 8 then
    raise exception 'Informations client invalides';
  end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'Panier vide';
  end if;

  for it in select * from jsonb_array_elements(p_items) loop
    select * into pr from products where id = (it->>'product_id')::uuid and active;
    if not found then raise exception 'Produit introuvable'; end if;
    q := greatest(1, least(20, coalesce((it->>'qty')::int, 1)));
    v := pr.variants -> ((it->>'variant')::int);
    if v is null then raise exception 'Option invalide pour %', pr.name; end if;
    if pr.stock >= 0 and pr.stock < q then raise exception 'Stock insuffisant pour %', pr.name; end if;
    line := jsonb_build_object('product_id', pr.id, 'name', pr.name, 'option', v->>'label',
                               'qty', q, 'unit', (v->>'price')::int, 'total', (v->>'price')::int * q);
    lines := lines || line;
    sub := sub + (v->>'price')::int * q;
    if pr.stock >= 0 then update products set stock = stock - q where id = pr.id; end if;
  end loop;

  if coalesce(p_coupon,'') <> '' then
    select * into c from coupons where upper(code) = upper(p_coupon) and active;
    if found then
      disc := least(sub, case when c.kind = 'pct' then round(sub * c.value / 100.0)::int else c.value end);
    end if;
  end if;
  tot := sub - disc;
  ocode := 'SH-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 6));

  insert into orders (code, customer_name, customer_phone, items, subtotal, discount, total, coupon, method, proof_path)
  values (ocode, trim(p_name), trim(p_phone), lines, sub, disc, tot,
          case when disc > 0 then upper(p_coupon) else null end, p_method, p_proof);

  return json_build_object('code', ocode, 'total', tot, 'items', lines);
end $$;
grant execute on function create_order(text,text,jsonb,text,text,text) to anon, authenticated;

-- ---------- Vérification d'un code promo ----------
create or replace function check_coupon(p_code text, p_subtotal int) returns json
language plpgsql security definer set search_path = public as $$
declare c coupons%rowtype; d int;
begin
  select * into c from coupons where upper(code) = upper(coalesce(p_code,'')) and active;
  if not found then return json_build_object('valid', false, 'discount', 0); end if;
  d := least(p_subtotal, case when c.kind = 'pct' then round(p_subtotal * c.value / 100.0)::int else c.value end);
  return json_build_object('valid', true, 'discount', d, 'code', upper(c.code));
end $$;
grant execute on function check_coupon(text,int) to anon, authenticated;

-- ---------- Suivi de commandes (par code) ----------
create or replace function track_orders(p_codes text[]) returns json
language sql security definer set search_path = public as $$
  select coalesce(json_agg(json_build_object(
    'code', code, 'status', status, 'items', items, 'total', total,
    'method', method, 'created_at', created_at) order by created_at desc), '[]'::json)
  from orders where code = any(p_codes)
$$;
grant execute on function track_orders(text[]) to anon, authenticated;

-- ---------- Stockage des preuves de paiement ----------
insert into storage.buckets (id, name, public) values ('proofs', 'proofs', false) on conflict (id) do nothing;
create policy "proofs upload" on storage.objects for insert to anon, authenticated with check (bucket_id = 'proofs');
create policy "proofs admin read" on storage.objects for select to authenticated using (bucket_id = 'proofs' and public.is_admin());

-- ---------- Données de départ (à modifier ensuite depuis l'admin) ----------
insert into categories (name, emoji, position) values
  ('Streaming','🎬',1), ('Musique','🎧',2), ('IA & Outils','🤖',3), ('Jeux','🎮',4), ('Cartes cadeaux','🎁',5), ('Packs','📦',6)
on conflict (name) do nothing;

insert into products (slug, name, category_id, description, color, initials, variants, stock, featured, is_pack, includes)
select v.slug, v.name, (select id from categories where name = v.cat), v.descr, v.color, v.ini, v.variants::jsonb, v.stock, v.featured, v.is_pack, v.includes
from (values
  ('netflix','Netflix Premium','Streaming','Profil personnel en qualité Ultra HD, sur téléphone, TV et ordinateur.','#C4202B','N','[{"label":"1 mois","price":3500},{"label":"3 mois","price":9500},{"label":"6 mois","price":18000}]',25,true,false,''),
  ('prime-video','Prime Video','Streaming','Films, séries et originaux Prime sur tous tes écrans.','#0E7490','P','[{"label":"1 mois","price":2000},{"label":"3 mois","price":5500}]',20,false,false,''),
  ('disney-plus','Disney+','Streaming','Disney, Marvel, Star Wars et National Geographic.','#1E3A8A','D+','[{"label":"1 mois","price":2500},{"label":"3 mois","price":7000}]',15,false,false,''),
  ('youtube-premium','YouTube Premium','Streaming','YouTube sans publicité, lecture en arrière-plan et YouTube Music.','#D1321E','Y','[{"label":"1 mois","price":2000},{"label":"3 mois","price":5500}]',30,true,false,''),
  ('spotify-premium','Spotify Premium','Musique','Musique sans pub, écoute hors ligne, qualité supérieure.','#15803D','S','[{"label":"1 mois","price":2000},{"label":"3 mois","price":5500},{"label":"12 mois","price":19000}]',40,true,false,''),
  ('deezer-premium','Deezer Premium','Musique','Écoute hors ligne et sans publicité.','#7C3AED','Dz','[{"label":"1 mois","price":1800},{"label":"3 mois","price":5000}]',12,false,false,''),
  ('chatgpt-plus','ChatGPT Plus','IA & Outils','Accès aux derniers modèles, réponses plus rapides, analyse de fichiers.','#0F766E','G','[{"label":"1 mois","price":9000},{"label":"3 mois","price":25000}]',10,true,false,''),
  ('gemini-pro','Gemini Pro','IA & Outils','L''assistant IA de Google avec les modèles avancés.','#2563EB','Ge','[{"label":"1 mois","price":7000},{"label":"12 mois","price":70000}]',10,false,false,''),
  ('canva-pro','Canva Pro','IA & Outils','Modèles premium, suppression d''arrière-plan et kit de marque.','#6D28D9','C','[{"label":"1 mois","price":1500},{"label":"12 mois","price":9000}]',50,true,false,''),
  ('capcut-pro','CapCut Pro','IA & Outils','Effets, modèles et export sans filigrane pour tes vidéos.','#27272A','Cp','[{"label":"1 mois","price":2500},{"label":"3 mois","price":6500}]',30,false,false,''),
  ('free-fire-diamants','Free Fire Diamants','Jeux','Recharge instantanée sur ton compte avec ton ID joueur.','#EA580C','FF','[{"label":"110 diamants","price":1000},{"label":"341 diamants","price":3000},{"label":"583 diamants","price":5000},{"label":"1 188 diamants","price":10000}]',-1,true,false,''),
  ('pubg-uc','PUBG Mobile UC','Jeux','Recharge d''UC avec ton ID joueur.','#CA8A04','UC','[{"label":"60 UC","price":1000},{"label":"325 UC","price":5000},{"label":"660 UC","price":10000}]',-1,false,false,''),
  ('carte-google-play','Carte Google Play','Cartes cadeaux','Code à utiliser dans le Play Store.','#16A34A','GP','[{"label":"Carte 5 $","price":3500},{"label":"Carte 10 $","price":6800},{"label":"Carte 25 $","price":16500}]',20,false,false,''),
  ('carte-steam','Carte Steam','Cartes cadeaux','Crédit Steam pour tes jeux PC.','#1D4F7C','St','[{"label":"Carte 5 $","price":3500},{"label":"Carte 10 $","price":6800},{"label":"Carte 20 $","price":13500}]',20,false,false,''),
  ('pack-createur','Pack Créateur','Packs','Tout pour créer : design, montage et IA pendant 1 mois.','#6D28D9','PC','[{"label":"1 mois","price":12000}]',10,true,true,E'Canva Pro, 1 mois\nCapCut Pro, 1 mois\nChatGPT Plus, 1 mois'),
  ('pack-divertissement','Pack Divertissement','Packs','Séries, musique et vidéos sans pub pendant 1 mois.','#C4202B','PD','[{"label":"1 mois","price":7000}]',10,true,true,E'Netflix Premium, 1 mois\nSpotify Premium, 1 mois\nYouTube Premium, 1 mois')
) as v(slug,name,cat,descr,color,ini,variants,stock,featured,is_pack,includes)
on conflict (slug) do nothing;

insert into coupons (code, kind, value) values ('PROMO10','pct',10), ('BIENVENUE','flat',500) on conflict (code) do nothing;

insert into settings (key, value) values
  ('shop_name', '"StaneHub"'),
  ('whatsapp', '"22600000000"'),
  ('pay_methods', '{"Orange Money":"+226 00 00 00 00","Moov Money":"+226 00 00 00 00","Wave":"+226 00 00 00 00"}'),
  ('tpl_order', '"Bonjour, commande {id} de {nom} : {produits}. Total {total}."'),
  ('tpl_delivered', '"Bonjour {nom}, ta commande {id} est livrée : {produits}. Voici tes accès ci-dessous. Merci de ta confiance !"'),
  ('tpl_relance', '"Bonjour {nom}, ta commande {id} ({total}) attend encore ton paiement. Envoie-nous la capture quand c''est fait."')
on conflict (key) do nothing;

insert into posts (slug, title, excerpt, body) values
 ('payer-avec-orange-money','Payer son abonnement avec Orange Money, pas à pas','Les étapes simples pour payer, envoyer ta preuve et recevoir ton accès.',E'Choisis ton service, ajoute-le au panier puis passe au paiement.\nEnvoie le montant au numéro indiqué avec ton application mobile money, puis prends une capture d''écran de la confirmation.\nAjoute cette capture à ta commande. Dès que le paiement est vérifié, tu reçois ton accès sur WhatsApp.'),
 ('netflix-spotify-youtube-lequel-choisir','Netflix, Spotify, YouTube : lequel choisir ?','Un petit guide selon ce que tu regardes et écoutes.',E'Si tu regardes surtout des séries, Netflix est le choix évident.\nSi tu passes ta journée à écouter de la musique, Spotify ou Deezer suffisent.\nSi tu regardes beaucoup de vidéos YouTube, l''abonnement Premium supprime les publicités et ajoute YouTube Music.')
on conflict (slug) do nothing;
