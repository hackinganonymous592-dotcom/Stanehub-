/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      fontFamily: { sans: ['"Plus Jakarta Sans"', "system-ui", "sans-serif"] },
      colors: {
        bg: "rgb(var(--bg) / <alpha-value>)",
        card: "rgb(var(--card) / <alpha-value>)",
        fg: "rgb(var(--fg) / <alpha-value>)",
        muted: "rgb(var(--muted) / <alpha-value>)",
        line: "rgb(var(--line) / <alpha-value>)",
        soft: "rgb(var(--soft) / <alpha-value>)",
        primary: "rgb(var(--primary) / <alpha-value>)",
        teal: "rgb(var(--teal) / <alpha-value>)",
        navy: "#1a1a2e",
        navy2: "#16213e",
      },
      boxShadow: {
        card: "0 2px 12px 0 rgba(0,0,0,.06), 0 4px 20px -4px rgba(0,0,0,.04)",
        lift: "0 8px 24px 0 rgba(0,0,0,.1), 0 12px 32px -6px rgba(0,0,0,.08)",
      },
    },
  },
  plugins: [],
};
